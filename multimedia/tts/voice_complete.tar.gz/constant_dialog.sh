#!/data/data/com.termux/files/usr/bin/bash

echo "🎤 Starting Constant Dialog Mode..."
echo "   Listening continuously and responding with TTS"
echo ""

# Default settings
RECORD_TIME=5  # Listen for 5 seconds at a time
TEMP_AUDIO="/tmp/voice_input.wav"

while true; do
    echo "🎤 Listening..."

    # Record from microphone
    termux-microphone-record -f "$TEMP_AUDIO" -l $RECORD_TIME -e opus -b 128 -r 44100 -c 1

    # Wait for recording to complete
    sleep $RECORD_TIME

    # Stop recording
    termux-microphone-record -q

    # Check if audio was captured
    if [ -f "$TEMP_AUDIO" ]; then
        echo "🎧 Processing audio..."

        # Convert speech to text (using termux-speech-to-text)
        USER_TEXT=$(termux-speech-to-text)

        if [ ! -z "$USER_TEXT" ]; then
            echo "👤 You said: $USER_TEXT"

            # Exit if user says stop/quit/exit
            if [[ "$USER_TEXT" =~ (stop|quit|exit|bye) ]]; then
                echo "👋 Ending constant dialog..."
                break
            fi

            # Generate response with Ruby TTS
            echo "🤖 Responding..."
            echo "$USER_TEXT" | ruby ~/natural_talk.rb
        else
            echo "⚠️  No speech detected, continuing..."
        fi

        # Clean up
        rm -f "$TEMP_AUDIO"
    else
        echo "❌ Failed to record. Check microphone permissions."
        sleep 2
    fi

    echo ""
done

echo "✅ Constant dialog ended."
