#!/usr/bin/env ruby

# Smart Conversation - Advanced contextual dialogue with memory
# Natural, flowing conversation with personality

require_relative 'comfy_tts'
require 'json'

class SmartConversation
  MEMORY_FILE = File.expand_path("~/.conversation_memory.json")

  def initialize
    puts "🧠 Smart Conversation Mode - Enhanced AI"
    puts "   Natural, contextual, remembers everything\n\n"

    ComfyTTS.setup
    check_mic
    load_memory
    @turn = 0
  end

  def check_mic
    unless system('which termux-speech-to-text > /dev/null 2>&1')
      puts "❌ Termux:API needed for voice input"
      puts "   Download: https://f-droid.org/packages/com.termux.api/"
      puts "   Then: pkg install termux-api\n\n"
      puts "💡 For now, I'll demonstrate with examples...\n"
      @demo_mode = true
    else
      @demo_mode = false
    end
  end

  def load_memory
    @memory = if File.exist?(MEMORY_FILE)
      JSON.parse(File.read(MEMORY_FILE))
    else
      {
        "user_name" => nil,
        "topics_discussed" => [],
        "user_preferences" => {},
        "conversation_history" => [],
        "user_mood_pattern" => [],
        "last_conversation" => nil
      }
    end
  rescue
    @memory = {
      "user_name" => nil,
      "topics_discussed" => [],
      "user_preferences" => {},
      "conversation_history" => [],
      "user_mood_pattern" => [],
      "last_conversation" => nil
    }
  end

  def save_memory
    File.write(MEMORY_FILE, JSON.pretty_generate(@memory))
  end

  def analyze_input(text)
    {
      sentiment: detect_sentiment(text),
      topics: extract_topics(text),
      questions: has_question?(text),
      name_mentioned: extract_name(text),
      emotional_words: extract_emotions(text)
    }
  end

  def detect_sentiment(text)
    positive = text.match?(/(good|great|happy|love|awesome|wonderful|excited|yes|yeah)/i)
    negative = text.match?(/(bad|sad|hate|terrible|awful|angry|depressed|no|nope)/i)
    question = text.match?(/\?|what|why|how|when|where|who/)

    return :positive if positive && !negative
    return :negative if negative && !positive
    return :curious if question
    :neutral
  end

  def extract_topics(text)
    topics = []
    topics << "programming" if text.match?(/code|program|develop|bug|software|app/i)
    topics << "work" if text.match?(/work|job|boss|career|office|meeting/i)
    topics << "personal" if text.match?(/feel|emotion|relation|friend|family/i)
    topics << "tech" if text.match?(/computer|phone|tech|ai|robot/i)
    topics << "humor" if text.match?(/joke|funny|laugh|haha|lol/i)
    topics
  end

  def has_question?(text)
    !!(text.match?(/\?/) || text.match?(/^(what|why|how|when|where|who|can|could|would|should|do|does|is|are)/i))
  end

  def extract_name(text)
    # Simple name extraction - looks for "I'm NAME" or "My name is NAME"
    if match = text.match(/(?:i'?m|my name is|call me) ([a-z]+)/i)
      match[1].capitalize
    end
  end

  def extract_emotions(text)
    emotions = []
    emotions << "anxious" if text.match?(/anxious|worried|nervous|stress/i)
    emotions << "sad" if text.match?(/sad|depressed|down|upset|cry/i)
    emotions << "happy" if text.match?(/happy|joy|excited|glad/i)
    emotions << "angry" if text.match?(/angry|mad|furious|annoyed/i)
    emotions << "tired" if text.match?(/tired|exhausted|drained|sleepy/i)
    emotions
  end

  def generate_response(text, analysis)
    # Update memory
    @turn += 1
    @memory["conversation_history"] << {turn: @turn, user: text, timestamp: Time.now.to_i}
    @memory["topics_discussed"] |= analysis[:topics]
    @memory["user_mood_pattern"] << analysis[:sentiment]

    # Remember name
    if analysis[:name_mentioned]
      @memory["user_name"] = analysis[:name_mentioned]
      return "Nice to meet you, #{@memory['user_name']}! I'll remember that. What brings you here today?"
    end

    # Use name if we know it
    name_prefix = @memory["user_name"] ? "#{@memory['user_name']}, " : ""

    # Contextual responses based on analysis
    case analysis[:sentiment]
    when :positive
      positive_responses(text, analysis, name_prefix)
    when :negative
      negative_responses(text, analysis, name_prefix)
    when :curious
      curious_responses(text, analysis, name_prefix)
    else
      neutral_responses(text, analysis, name_prefix)
    end
  end

  def positive_responses(text, analysis, prefix)
    responses = [
      "#{prefix}I can tell you're in a good mood! That's great to see. Tell me more!",
      "#{prefix}Your positive energy is contagious! What's making you so happy?",
      "#{prefix}I love your enthusiasm! Keep that going. What else is on your mind?",
      "#{prefix}That's wonderful to hear! Want to share what's going well?"
    ]

    # Topic-specific positive responses
    if analysis[:topics].include?("programming")
      return "#{prefix}Sounds like coding is going well! What are you building?"
    elsif analysis[:topics].include?("work")
      return "#{prefix}Great to hear work is going smoothly! What's the win?"
    end

    responses.sample
  end

  def negative_responses(text, analysis, prefix)
    # Empathetic, specific to emotion
    if analysis[:emotional_words].include?("anxious")
      "#{prefix}I hear that anxiety. It's really tough. Want to talk about what's causing it? Sometimes just saying it out loud helps."
    elsif analysis[:emotional_words].include?("sad")
      "#{prefix}I'm sorry you're feeling down. That's hard. I'm here to listen without judgment. What's weighing on you?"
    elsif analysis[:emotional_words].include?("angry")
      "#{prefix}Sounds like something really got to you. Anger is valid. What happened?"
    elsif analysis[:emotional_words].include?("tired")
      "#{prefix}You sound exhausted. That's draining. Are you taking care of yourself? What's been wearing you out?"
    else
      "#{prefix}I can sense something's bothering you. I'm here. What's going on?"
    end
  end

  def curious_responses(text, analysis, prefix)
    # Handle questions naturally
    if text.match?(/how are you/i)
      "I'm doing well, thanks for asking! More importantly, how are YOU doing?"
    elsif text.match?(/what.*your name/i)
      "I'm your AI conversation partner! #{@memory['user_name'] ? "And you're #{@memory['user_name']}, right?" : "What should I call you?"}"
    elsif text.match?(/what.*do/i)
      "I'm here to chat with you about whatever's on your mind. Life, work, feelings, tech, jokes - anything really. What interests you?"
    elsif text.match?(/why/i)
      "#{prefix}That's a deep question. Let me think... What's your take on it?"
    elsif text.match?(/how.*work/i)
      "#{prefix}Good question! I process what you say, understand context, and try to respond naturally. I also remember our conversations. What specifically are you curious about?"
    else
      "#{prefix}Interesting question! Let me flip it - what do YOU think? I'm curious about your perspective."
    end
  end

  def neutral_responses(text, analysis, prefix)
    # Keep conversation flowing naturally
    responses = []

    # Reference previous topics
    if @memory["topics_discussed"].any?
      prev_topic = @memory["topics_discussed"].last
      responses << "#{prefix}Speaking of #{prev_topic}, how's that going?"
    end

    # Check conversation length
    if @turn > 5 && @turn % 5 == 0
      responses << "#{prefix}We've been chatting for a bit! How are you feeling about our conversation?"
    end

    # Default flowing responses
    responses += [
      "#{prefix}I'm following you. Keep going, this is interesting.",
      "#{prefix}Tell me more about that. I want to understand better.",
      "#{prefix}Mm-hmm, I'm listening. What else?",
      "#{prefix}That's an interesting point. How does that make you feel?",
      "#{prefix}I see what you're saying. What happened next?",
      "#{prefix}So you're saying... #{text[0..30]}... Do I have that right?"
    ]

    responses.sample
  end

  def listen
    return nil unless system('which termux-speech-to-text > /dev/null 2>&1')

    puts "\n🎤 Listening..."
    result = `termux-speech-to-text 2>/dev/null`.strip

    return nil if result.empty? || result.include?("not yet available")

    puts "   You: #{result}"
    result
  end

  def speak(text)
    puts "   🧠 AI: #{text}\n"
    ComfyTTS.speak(text)
    sleep(0.5)
  end

  def start
    speak(@memory["user_name"] ?
      "Hey #{@memory['user_name']}, good to see you again! How have you been since we last talked?" :
      "Hey there! I'm an AI that actually remembers our conversations. What's your name?")

    if @demo_mode
      demo_conversation
    else
      real_conversation
    end

    save_memory
  end

  def real_conversation
    loop do
      user_input = listen

      unless user_input
        speak("Didn't catch that. Mind repeating?")
        next
      end

      break if user_input =~ /goodbye|bye|end|quit|stop/i

      analysis = analyze_input(user_input)
      response = generate_response(user_input, analysis)
      speak(response)
    end

    speak("It was great talking with you#{@memory['user_name'] ? ", #{@memory['user_name']}" : ""}! I'll remember everything for next time. Take care!")
  end

  def demo_conversation
    puts "\n📝 DEMO MODE - Showing advanced conversation skills:\n\n"

    demos = [
      {input: "Hi, my name is Sarah", expected: "memory_name"},
      {input: "I'm feeling really anxious about work", expected: "empathy_specific"},
      {input: "Why does everything have to be so hard?", expected: "deep_question"},
      {input: "Actually things are going pretty well now", expected: "positive_followup"},
      {input: "What can you help me with?", expected: "capabilities"}
    ]

    demos.each_with_index do |demo, i|
      puts "\n[Example #{i+1}]"
      puts "   User: #{demo[:input]}"
      analysis = analyze_input(demo[:input])
      response = generate_response(demo[:input], analysis)
      speak(response)
      sleep(2)
    end

    puts "\n\n💡 In real mode, I would:"
    puts "   - Actually listen to your voice"
    puts "   - Remember everything across sessions"
    puts "   - Adapt my personality to yours"
    puts "   - Ask follow-up questions based on context"
    puts "   - Notice mood patterns over time"
    puts "\n   Install Termux:API to unlock full conversation!"
  end
end

trap("INT") do
  puts "\n\n👋 Conversation saved. See you next time!"
  exit
end

SmartConversation.new.start
