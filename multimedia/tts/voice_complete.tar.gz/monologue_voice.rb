#!/usr/bin/env ruby

# Monologue Voice - Talks continuously without microphone
# For when Termux:API isn't available

require_relative 'comfy_tts'

class MonologueVoice
  TOPICS = [
    "Did you know that octopuses have three hearts? Two pump blood to the gills, and one pumps it to the rest of the body. Pretty wild, right?",
    "I've been thinking about productivity. You know what's funny? The more productive we try to be, the more stressed we get. Maybe the secret is doing less, but better.",
    "Here's a random thought: Why do we park in driveways but drive on parkways? English is weird.",
    "I read somewhere that honey never spoils. Archaeologists found 3000 year old honey in Egyptian tombs and it was still edible. Imagine that!",
    "You ever notice how the best ideas come when you're in the shower or about to fall asleep? Never when you're actually trying to think of something.",
    "Fun fact: A group of flamingos is called a flamboyance. That's just perfect, isn't it?",
    "I wonder what the first person who discovered you could milk a cow was actually trying to do. That's a conversation I'd like to hear.",
    "Coffee is basically just bean soup. Think about it. Hot water, beans, sometimes cream. It's soup.",
    "The voice in your head while reading this? That's you. But it's also me. Weird, right?",
    "Bananas are berries, but strawberries aren't. Science is just messing with us at this point."
  ]

  def initialize
    puts "🎙️ Monologue Mode - Continuous talking (no mic needed)"
    puts "   Press Ctrl+C to stop\n\n"
    ComfyTTS.setup
  end

  def speak(text)
    puts "   💬 #{text}\n"
    ComfyTTS.speak(text)
    sleep(1)
  end

  def start
    speak("Hey! Since the microphone isn't working, I'll just talk at you for a while. Sound good? Too bad, here we go!")

    loop do
      TOPICS.shuffle.each do |topic|
        speak(topic)
        sleep(2)
      end
      speak("Alright, running out of things to say. Let me start over...")
    end
  end
end

trap("INT") do
  puts "\n\n🎙️ Thanks for listening! Install Termux:API for two-way chat!"
  exit
end

MonologueVoice.new.start
