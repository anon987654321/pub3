#!/usr/bin/env ruby

# Continuous Dialogue with TTS
# Using espeak for immediate functionality (you can upgrade to XTTS-V2 later)

require 'open3'

class DialogueBot
  def initialize
    @conversation_history = []
    check_tts_available
  end

  def check_tts_available
    # Check if espeak is available
    unless system('which espeak > /dev/null 2>&1')
      puts "⚠️  espeak not found. Install with: pkg install espeak"
      exit 1
    end
  end

  def speak(text)
    puts "\n🤖 Bot: #{text}"
    # Speak with espeak (fast and immediate)
    system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
  end

  def get_response(user_input)
    # Simple conversational responses
    responses = {
      /hello|hi|hey/i => [
        "Hello! How are you doing today?",
        "Hey there! What's on your mind?",
        "Hi! Nice to talk with you!"
      ],
      /how are you|what's up|wassup/i => [
        "I'm doing great! Ready to chat. What about you?",
        "I'm here and ready to talk! How can I help?",
        "All systems go! What would you like to discuss?"
      ],
      /your name|who are you/i => [
        "I'm your dialogue companion! Just here to chat with you.",
        "I'm a TTS bot, always ready for conversation!",
        "Call me your talking friend!"
      ],
      /bye|goodbye|exit|quit/i => [
        "Goodbye! It was nice talking with you!",
        "See you later! Take care!",
        "Bye! Come back anytime!"
      ],
      /thank|thanks/i => [
        "You're welcome!",
        "Happy to help!",
        "Anytime, my friend!"
      ],
      /weather/i => [
        "I can't check the weather, but I hope it's nice where you are!",
        "Weather talk, eh? Perfect conversation starter!"
      ],
      /joke|funny/i => [
        "Why did the Ruby programmer quit? Because they didn't get arrays!",
        "What do you call a programmer from Finland? Nerdic!",
        "Why do programmers prefer dark mode? Because light attracts bugs!"
      ]
    }

    # Find matching response
    responses.each do |pattern, possible_responses|
      if user_input =~ pattern
        return possible_responses.sample
      end
    end

    # Default responses if no pattern matches
    default_responses = [
      "That's interesting! Tell me more.",
      "I see. What else is on your mind?",
      "Hmm, #{user_input}... fascinating!",
      "Go on, I'm listening!",
      "That's cool! What do you think about it?",
      "Really? That's something to think about!",
      "I hear you. Want to talk more about that?"
    ]

    default_responses.sample
  end

  def start
    speak("Hello! I'm ready to talk. Say something, or type 'quit' to exit.")

    loop do
      print "\n👤 You: "
      user_input = gets.chomp.strip

      # Exit conditions
      if user_input.downcase =~ /^(quit|exit|bye|goodbye)$/
        speak("Goodbye! It was great talking with you!")
        break
      end

      # Skip empty inputs
      next if user_input.empty?

      # Get and speak response
      response = get_response(user_input)
      speak(response)
    end
  end
end

# Start the dialogue
bot = DialogueBot.new
bot.start
