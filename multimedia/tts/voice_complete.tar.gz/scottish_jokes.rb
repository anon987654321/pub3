#!/usr/bin/env ruby

# Scottish Joke Bot with Best SoX Effects!
# Scottish accent + Echo + Reverb + Bass

require 'fileutils'

class ScottishJokeBot
  def initialize
    @jokes = [
      "Och aye! Why did the Scotsman wear two jackets when painting? The can said put on two coats!",
      "A Scotsman walks into a bar... the Englishman ducked!",
      "What's the difference between a Scottish wedding and a Scottish funeral? One less drunk!",
      "How do you get a Scotsman onto the roof? Tell him the drinks are on the house!",
      "Why don't Scots ever play hide and seek? Because good luck hiding when you're wearing a kilt!",
      "A Scotsman found a bottle with a genie. The genie said I'll grant ye one wish. The Scot said make me irresistible to women. Poof! He turned into a credit card!",
      "What do you call a Scotsman with a sheep under each arm? A pimp!",
      "How does a Scotsman find a sheep in tall grass? Verra satisfying!",
      "Why are Scotsmen so good at golf? They know how to get more bang for their bucks!",
      "What's a Scottish seven course meal? A six pack and a potato!",
      "How do Scottish people greet each other? Och aye the noo!",
      "Why did the Scotsman put his money in the freezer? He wanted cold hard cash!",
      "What do you call a Scotsman who's been lying in the sun too long? Baked McTavish!",
      "Why don't Scots use elevators? They prefer to take the stairs because it's free!",
      "A Scotsman invented the copper wire... Two Scots fighting over a penny!",
      "What's the Scottish take on global warming? Finally, decent weather!",
      "Why are Scottish jokes so short? So the English can understand them!",
      "How many Scots does it take to change a lightbulb? None, they'll just sit in the dark rather than waste money!",
      "What's a Scotsman's favorite type of music? Bagpipe rock and roll!",
      "Why did the Scotsman cross the road? To get to the cheaper side!"
    ]

    @reactions = [
      "Och, that's a belter!",
      "Aye, pure dead brilliant!",
      "Haud yer wheesht and laugh!",
      "Dinnae stop me now!",
      "Och aye, here's another cracker!",
      "Pure Scottish comedy gold!",
      "Away and bile yer heid with laughter!",
      "That's pure mental!",
      "Och, yer aff yer heid!",
      "Bonnie good joke that!"
    ]

    puts "🏴󠁧󠁢󠁳󠁣󠁴󠁿 Initializing Scottish joke bot with premium effects..."
    check_dependencies
    @cache_dir = File.expand_path("~/.tts_cache_scottish")
    FileUtils.mkdir_p(@cache_dir)
  end

  def check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end

    unless system('which sox > /dev/null 2>&1')
      puts "Installing sox for Scottish effects..."
      system('pkg install -y sox')
    end
  end

  def speak(text)
    puts "\n🏴󠁧󠁢󠁳󠁣󠁴󠁿 #{text}"

    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"
      scottish_file = "#{@cache_dir}/scottish_#{text_hash}.wav"

      unless File.exist?(scottish_file)
        puts "   [Applying Scottish accent + premium effects...]"

        # Use UK TTS for better accent
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.uk', slow=False); tts.save('#{audio_file}')\" 2>/dev/null")

        if File.exist?(audio_file) && File.size(audio_file) > 0
          # Premium Scottish effects: pitch down slightly, add echo, reverb, bass boost, and warmth
          system("sox #{audio_file} #{scottish_file} pitch -100 bass +4 echo 0.8 0.88 60 0.4 echo 0.8 0.88 120 0.3 reverb 40 treble -2 chorus 0.5 0.9 50 0.4 0.25 2 -t norm -2 2>/dev/null")
        end
      end

      if File.exist?(scottish_file) && File.size(scottish_file) > 0
        system("play-audio #{scottish_file} 2>/dev/null")
      else
        raise "Failed to generate Scottish voice"
      end

    rescue => e
      puts "   [Error: #{e.message}]"
      system("espeak -s 140 -p 40 -v en-scottish '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.7)
  end

  def start
    puts "\n🏴󠁧󠁢󠁳󠁣󠁴󠁿 Starting Scottish comedy show!"
    puts "    Effects: Pitch Down + Echo + Reverb + Bass + Chorus\n\n"

    speak("Och aye! Welcome tae the Scottish comedy hour! Get ready fer some proper Scottish humor!")

    loop do
      @jokes.each do |joke|
        speak(joke)
        speak(@reactions.sample)
      end

      speak("Och, here's another round of Scottish crackers!")
    end
  end
end

trap("INT") do
  puts "\n\n🏴󠁧󠁢󠁳󠁣󠁴󠁿 Och, cheerio! The Scottish comedy show is ending!"
  system("python3 -c \"from gtts import gTTS; tts = gTTS('Och cheerio! Thanks fer listening!', lang='en', tld='co.uk'); tts.save('/tmp/bye_scot.mp3')\" 2>/dev/null")
  system("sox /tmp/bye_scot.mp3 /tmp/bye_scot.wav pitch -100 bass +4 echo 0.8 0.88 60 0.4 reverb 40 norm -2 2>/dev/null")
  system("play-audio /tmp/bye_scot.wav 2>/dev/null")
  File.delete("/tmp/bye_scot.mp3") if File.exist?("/tmp/bye_scot.mp3")
  File.delete("/tmp/bye_scot.wav") if File.exist?("/tmp/bye_scot.wav")
  exit
end

bot = ScottishJokeBot.new
bot.start
