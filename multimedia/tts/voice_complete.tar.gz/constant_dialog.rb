#!/usr/bin/env ruby

# Constant Two-Way Dialog - Continuous mic conversation with funny responses
# Keeps listening and responding without stopping

require_relative 'comfy_tts'

class ConstantDialog
  RESPONSES = {
    /hello|hi|hey/i => ["Hey there! What's up?", "Hello! Nice to hear from you!", "Hi! How can I help?"],
    /how are you/i => ["I'm great! How about you?", "Doing fantastic! Thanks for asking!", "Never better! You?"],
    /weather/i => ["The weather is whatever you want it to be in your imagination!", "It's always sunny in code land!"],
    /time/i => -> { "It's currently #{Time.now.strftime('%I:%M %p')}. Time flies when you're coding!" },
    /date/i => -> { "Today is #{Time.now.strftime('%A, %B %d, %Y')}. Another beautiful day!" },
    /joke|funny/i => [
      "Why do programmers prefer dark mode? Because light attracts bugs!",
      "What's a pirate's favorite programming language? Arrrrr!",
      "There are 10 types of people. Those who understand binary and those who don't.",
      "Why did the developer go broke? Because he used up all his cache!",
      "How do you comfort a JavaScript bug? You console it!"
    ],
    /thank|thanks/i => ["You're welcome!", "Anytime!", "Happy to help!", "No problem at all!"],
    /love|like/i => ["Aww, I like you too!", "That's so sweet!", "You're awesome!"],
    /name/i => ["I'm your constant companion voice assistant!", "You can call me Voice Bot!", "I'm just a friendly AI voice!"],
    /sing/i => ["La la la! I'm not much of a singer!", "Do re mi fa so la ti do! That's all I've got!"],
    /stop|quit|exit|bye/i => ["Okay, goodbye! It was fun talking!", "See you later!", "Catch you next time!"]
  }.freeze

  FALLBACKS = [
    "That's interesting! Tell me more.",
    "I see. What else is on your mind?",
    "Hmm, fascinating! Keep talking.",
    "I'm listening. Go on!",
    "That's cool! What else?",
    "Interesting point! Continue.",
    "I hear you! What's next?",
    "Tell me more about that!",
    "That sounds great! Keep going.",
    "I'm all ears! Or... well, microphone."
  ].freeze

  def initialize
    puts "🎤 Initializing constant two-way dialog..."
    check_dependencies
    ComfyTTS.setup
    @conversation_count = 0
  end

  def check_dependencies
    unless system('which termux-speech-to-text > /dev/null 2>&1')
      puts "❌ Error: termux-api required"
      puts "Install: pkg install termux-api"
      exit 1
    end
  end

  def listen
    puts "\n🎤 Listening... (say 'quit' to stop)"
    result = `termux-speech-to-text 2>/dev/null`.strip

    return nil if result.empty?

    @conversation_count += 1
    puts "   [#{@conversation_count}] You: #{result}"
    result
  end

  def speak(text)
    puts "   🔊 Assistant: #{text}"
    ComfyTTS.speak(text)
    sleep(0.3)
  end

  def get_response(user_input)
    return nil if user_input.downcase =~ /^(quit|exit|bye|goodbye|stop)$/

    RESPONSES.each do |pattern, response|
      if user_input =~ pattern
        return response.is_a?(Proc) ? response.call : response.sample
      end
    end

    FALLBACKS.sample
  end

  def start
    puts "\n" + "="*50
    puts "🎤 CONSTANT TWO-WAY DIALOG ACTIVE"
    puts "="*50
    puts "  Say anything and I'll respond!"
    puts "  Say 'quit', 'exit', or 'bye' to end"
    puts "="*50 + "\n"

    speak("Hello! I'm ready for constant conversation. Let's chat!")

    loop do
      user_input = listen

      unless user_input
        speak("I didn't catch that. Try again?")
        next
      end

      response = get_response(user_input)

      unless response
        speak("Goodbye! We had #{@conversation_count} exchanges. Take care!")
        break
      end

      speak(response)
    end
  end
end

# Handle Ctrl+C gracefully
trap("INT") do
  puts "\n\n🎤 Dialog interrupted. Goodbye!"
  exit
end

# Start the constant dialog
ConstantDialog.new.start
