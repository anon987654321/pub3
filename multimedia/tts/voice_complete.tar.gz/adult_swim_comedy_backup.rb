#!/usr/bin/env ruby

# Adult Swim Abstract Comedy Bot
# Surreal, weird, experimental humor with trippy effects

require 'fileutils'

class AdultSwimComedyBot
  def initialize
    @abstract_bits = [
      "What if clouds were just the sky's dandruff? Think about it.",
      "I told my therapist I have dreams about being a calculator. He said that's normal.",
      "The universe is just God's screensaver. Change my mind.",
      "Time is just a construct invented by clock companies to sell more clocks.",
      "What if déjà vu is just your save file loading?",
      "Parallel universes are just spoilers for your life.",
      "Reality is the loading screen between dreams.",
      "Your thoughts are just your brain arguing with itself.",
      "What if colors are different for everyone but we just call them the same names?",
      "Mirrors are just portals but both sides are boring.",
      "The alphabet is in that order because of the song. Admit it.",
      "What if plants are farming us? Giving us oxygen until we decompose as fertilizer?",
      "Sleep is just death being shy.",
      "Your entire life is just your brain describing itself to itself.",
      "What if oxygen is slowly killing us and it just takes seventy to eighty years?",
      "The internet is just people yelling at each other in different fonts.",
      "Consciousness is just the universe experiencing itself. Hi universe, nice meeting you.",
      "What if nothing is real and we're all just background characters in someone's dream?",
      "Your skeleton is always wet. You're welcome.",
      "Every photo of you is from when you were younger. Except this one was from the future.",
      "What if reality TV is actually reality and our life is the TV show?",
      "Your tongue never sits comfortably in your mouth. You're now aware of it.",
      "Somewhere in the multiverse, you're a god. But not here. Sorry.",
      "What if elevators are just rooms that feel like moving?",
      "The brain named itself. Let that sink in.",
      "You are technically always looking at the past because light takes time to reach your eyes.",
      "What if chairs are just tiny floors for your butt?",
      "Reality is just a shared hallucination we all agreed on.",
      "Your dog doesn't know you can't understand barking. They think you're ignoring them.",
      "What if gravity is just the Earth being really clingy?"
    ]

    @transitions = [
      "But wait, there's more...",
      "Meanwhile, in another dimension...",
      "Plot twist:",
      "The simulation continues...",
      "Existential crisis in 3, 2, 1...",
      "Your brain has left the chat.",
      "Loading reality dot dot dot",
      "Error 404: Sanity not found.",
      "We now return to your regular programming.",
      "Breaking news from the void:",
      "Brought to you by entropy.",
      "This message approved by chaos.",
      "The absurdity intensifies.",
      "Your consciousness has been updated.",
      "Thank you for existing."
    ]

    puts "📺 Initializing Adult Swim abstract comedy..."
    check_dependencies
    @cache_dir = File.expand_path("~/.tts_cache_abstract")
    FileUtils.mkdir_p(@cache_dir)
  end

  def check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end

    unless system('which sox > /dev/null 2>&1')
      puts "Installing sox for trippy effects..."
      system('pkg install -y sox')
    end
  end

  def speak(text, effect_type = :normal)
    puts "\n📺 #{text}"

    begin
      text_hash = "#{text.hash.abs}_#{effect_type}"
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"
      trippy_file = "#{@cache_dir}/abstract_#{text_hash}.wav"

      unless File.exist?(trippy_file)
        puts "   [Applying #{effect_type} reality distortion...]"

        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com', slow=False); tts.save('#{audio_file}')\" 2>/dev/null")

        if File.exist?(audio_file) && File.size(audio_file) > 0
          case effect_type
          when :trippy
            # Phaser + chorus + light tremolo (no echo/reverb)
            system("sox #{audio_file} #{trippy_file} phaser 0.7 0.7 3 0.5 2 -t chorus 0.6 0.8 55 0.4 0.25 2 -t tremolo 6 0.4 norm -1 2>/dev/null")
          when :glitch
            # Light pitch shift + overdrive (no echo/reverb)
            system("sox #{audio_file} #{trippy_file} pitch -100 overdrive 8 8 tremolo 10 0.5 norm -1 2>/dev/null")
          when :void
            # Deeper voice only (no echo/reverb)
            system("sox #{audio_file} #{trippy_file} pitch -250 bass +5 chorus 0.6 0.8 45 0.3 0.2 2 -t norm -1 2>/dev/null")
          when :static
            # Light static effect (no echo/reverb)
            system("sox #{audio_file} #{trippy_file} overdrive 5 5 phaser 0.5 0.6 3 0.5 2 -t tremolo 8 0.4 norm -1 2>/dev/null")
          else
            # Normal but slightly weird (no echo/reverb)
            system("sox #{audio_file} #{trippy_file} pitch -50 chorus 0.5 0.8 50 0.3 0.2 2 -t norm -1 2>/dev/null")
          end
        end
      end

      if File.exist?(trippy_file) && File.size(trippy_file) > 0
        system("play-audio #{trippy_file} 2>/dev/null")
      else
        raise "Failed to generate abstract voice"
      end

    rescue => e
      puts "   [Error: #{e.message}]"
      system("espeak -s 145 -p 45 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.8)
  end

  def start
    puts "\n📺 Adult Swim Abstract Comedy Hour!"
    puts "    Reality Status: Questionable\n"
    puts "    Effects: Trippy + Glitch + Void + Static\n\n"

    effect_types = [:trippy, :glitch, :void, :static, :normal]
    effect_index = 0

    speak("Welcome to the void. Where logic goes to die.", :void)
    speak("This is your brain on abstract comedy.", :trippy)

    loop do
      @abstract_bits.each do |bit|
        current_effect = effect_types[effect_index % effect_types.length]
        speak(bit, current_effect)
        effect_index += 1

        if rand < 0.3
          speak(@transitions.sample, effect_types[(effect_index + 2) % effect_types.length])
          effect_index += 1
        end
      end

      speak("The absurdity continues. There is no escape.", :glitch)
      effect_index += 1
    end
  end
end

trap("INT") do
  puts "\n\n📺 Reality has been restored. Or has it?"
  system("python3 -c \"from gtts import gTTS; tts = gTTS('Thank you for watching. None of this was real.', lang='en'); tts.save('/tmp/bye_swim.mp3')\" 2>/dev/null")
  system("sox /tmp/bye_swim.mp3 /tmp/bye_swim.wav pitch -200 reverb 80 echo 0.8 0.9 150 0.4 phaser 0.8 0.8 3 0.5 2 -t norm -2 2>/dev/null")
  system("play-audio /tmp/bye_swim.wav 2>/dev/null")
  File.delete("/tmp/bye_swim.mp3") if File.exist?("/tmp/bye_swim.mp3")
  File.delete("/tmp/bye_swim.wav") if File.exist?("/tmp/bye_swim.wav")
  exit
end

bot = AdultSwimComedyBot.new
bot.start
