#!/usr/bin/env ruby

# Voice Effects Library - All sox effects in one place
# DRY principle: single source for all voice transformations

module VoiceEffects
  EFFECTS = {
    # Core personalities
    comfy: "pitch -60 bass +4 treble -2 compand 0.3,1 6:-70,-60,-20 -5 -90 0.2 chorus 0.6 0.9 55 0.4 0.3 2 -s reverb 15 norm -2",
    nervous: "pitch 150 tremolo 8 40 tempo 0.95 norm -8",

    # Character voices
    chipmunk: "pitch 600 tempo 1.3 treble +8 chorus 0.5 0.9 50 0.4 0.25 2 -s norm -3",
    monster: "pitch -800 tempo 0.7 bass +10 treble -8 reverb 80 overdrive 10 norm -3",
    robot: "overdrive 15 15 tremolo 30 0.5 phaser 0.6 0.66 3 0.6 2 -t norm -3",
    alien: "pitch 200 flanger chorus 0.7 0.9 55 0.4 0.25 2 -t phaser 0.8 0.74 3 0.4 0.5 -t echo 0.8 0.88 60 0.4 reverb 40 norm -3",
    drunk: "tempo 0.75 tremolo 3 50 pitch -100 chorus 0.6 0.9 50 0.4 0.25 2 -s norm -3",
    oldman: "pitch -200 tempo 0.6 tremolo 6 30 highpass 300 lowpass 3000 norm -3",
    baby: "pitch 800 tempo 0.8 treble +5 norm -5",

    # Effects
    echo: "reverb 90 echo 0.8 0.9 1000 0.3 echo 0.8 0.9 1800 0.25 echo 0.8 0.9 2600 0.2 norm -3",
    underwater: "lowpass 800 chorus 0.7 0.9 55 0.4 0.25 2 -t tempo 0.9 reverb 60 norm -3",
    telephone: "highpass 300 lowpass 3400 overdrive 5 norm -3",
    glitch: "tremolo 20 0.5 phaser 0.6 0.66 3 0.6 2 -t overdrive 8 norm -3",

    # Music effects
    autotune: "pitch 100 tremolo 5 0.8 chorus 0.7 0.9 50 0.4 0.25 2 -s reverb 50 echo 0.8 0.88 60 0.4 norm -3",
    deep: "pitch -600 bass +6 tempo 0.95 norm -3"
  }

  def self.apply(input_file, output_file, effect_name)
    effects = EFFECTS[effect_name.to_sym] || EFFECTS[:comfy]
    system("sox #{input_file} #{output_file} #{effects} 2>/dev/null")
  end

  def self.list
    EFFECTS.keys
  end

  def self.custom(input_file, output_file, custom_effects)
    system("sox #{input_file} #{output_file} #{custom_effects} 2>/dev/null")
  end
end
