#!/data/data/com.termux/files/usr/bin/bash

# Stop Background TTS Service

if [ -f ~/tts_service.pid ]; then
    PID=$(cat ~/tts_service.pid)
    echo "🛑 Stopping background service (PID: $PID)..."
    kill $PID 2>/dev/null
    rm ~/tts_service.pid
    echo "✅ Service stopped!"
else
    echo "⚠️  No background service running"
fi
