#!/usr/bin/env ruby

# Voice Dialog - Interactive mic conversation
# Applies master.json: DRY, ultraminimalism, internalize_first

require_relative 'comfy_tts'

class VoiceDialog
  RESPONSES = {
    /hello|hi|hey/ => "Hello! How can I help you today?",
    /how are you/ => "I'm doing well, thanks for asking. How are you?",
    /weather/ => "I can't check the weather, but I hope it's nice where you are.",
    /time/ => -> { "The current time is #{Time.now.strftime('%I:%M %p')}." },
    /date/ => -> { "Today is #{Time.now.strftime('%A, %B %d, %Y')}." }
  }.freeze

  FALLBACKS = [
    "That's interesting. Tell me more.",
    "I understand. What else would you like to discuss?",
    "Thanks for sharing that with me.",
    "I see. Is there anything specific you'd like help with?",
    "Noted. What's on your mind?"
  ].freeze

  def initialize
    puts "🎤 Initializing voice dialog..."
    check_speech_to_text
    ComfyTTS.setup
  end

  def check_speech_to_text
    unless system('which termux-speech-to-text > /dev/null 2>&1')
      puts "Error: termux-api required"
      exit 1
    end
  end

  def listen
    puts "\n🎤 Listening..."
    result = `termux-speech-to-text 2>/dev/null`.strip

    return nil if result.empty?

    puts "   You: #{result}"
    result
  end

  def speak(text)
    puts "   Assistant: #{text}"
    ComfyTTS.speak(text)
    sleep(0.5)
  end

  def get_response(user_input)
    RESPONSES.each do |pattern, response|
      return response.is_a?(Proc) ? response.call : response if user_input.downcase =~ pattern
    end
    FALLBACKS.sample
  end

  def start
    puts "\n🎤 Voice Dialog Active!"
    puts "    Say 'quit' to end\n"

    speak("Voice dialog ready. What would you like to talk about?")

    loop do
      user_input = listen

      unless user_input
        speak("I didn't catch that. Could you repeat?")
        next
      end

      break if user_input.downcase =~ /^(quit|exit|bye|goodbye)$/

      speak(get_response(user_input))
    end

    speak("Goodbye! Take care.")
  end
end

trap("INT") do
  puts "\n\n🎤 Ending voice dialog."
  exit
end

VoiceDialog.new.start
