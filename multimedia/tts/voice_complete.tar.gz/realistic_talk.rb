#!/usr/bin/env ruby

# Realistic Voice Continuous Dialogue using XTTS-V2
# Much more natural and human-like than espeak!

require 'replicate'
require 'open-uri'
require 'fileutils'

class RealisticTalkBot
  def initialize
    # Set up Replicate API
    @api_token = ENV['REPLICATE_API_TOKEN']

    if @api_token.nil? || @api_token.empty?
      puts "⚠️  REPLICATE_API_TOKEN not set!"
      puts "Get your free API token at: https://replicate.com/account/api-tokens"
      puts "Then run: export REPLICATE_API_TOKEN='your-token-here'"
      exit 1
    end

    @client = Replicate::Client.new(api_token: @api_token)
    @audio_cache = {}

    @topics = [
      "Hello! I'm your talking companion with a realistic voice. Can you hear the difference?",
      "This is high quality text to speech using advanced AI. Pretty cool, right?",
      "I sound much more natural than basic espeak. That's the power of modern TTS!",
      "Did you know that Ruby was created by Yukihiro Matsumoto in 1995?",
      "Text to speech has evolved dramatically. We can now sound almost human!",
      "I love having continuous conversations. It feels like we're really talking!",
      "Here's something interesting: AI voice synthesis can now clone voices perfectly.",
      "The quality of my voice comes from a model called XTTS version 2.",
      "This technology can speak in over 12 different languages with emotional expression.",
      "I could talk all day with this realistic voice. It's so much better!",
      "Let me tell you a joke: Why do programmers prefer dark mode? Because light attracts bugs!",
      "Communication through voice is powerful. It connects us better than text alone.",
      "Every word I speak is synthesized in real-time using advanced neural networks.",
      "Technology is amazing. We're having a conversation powered by artificial intelligence!",
      "I'm designed to sound as natural as possible. What do you think?",
      "This is the future of human-computer interaction. Voice-based AI assistants!",
      "If you want me to stop talking, just press Control C.",
      "I'm like a radio host that never runs out of things to say!",
      "Voice synthesis has applications in audiobooks, assistants, and accessibility tools.",
      "Thanks for listening to me. Your attention means everything!"
    ]

    puts "🎙️  Initializing realistic voice system..."
    check_dependencies
  end

  def check_dependencies
    # Check for audio player
    unless system('which mpg123 > /dev/null 2>&1')
      puts "Installing mpg123 for audio playback..."
      system('pkg install -y mpg123')
    end
  end

  def speak(text)
    puts "\n🤖 #{text}"

    begin
      # Generate speech using XTTS-V2
      puts "   [Generating realistic voice...]"

      prediction = @client.run(
        "cjwbw/xtts-v2",
        input: {
          text: text,
          speaker: "https://replicate.delivery/pbxt/JJy1BS2jbfP4ZUXfciaBT3OLqREqXF4xledeFLjLpUQqPf1JA/male.wav",
          language: "en",
          cleanup_voice: true
        }
      )

      # Download and play the audio
      audio_url = prediction
      audio_file = "/tmp/speech_#{Time.now.to_i}.wav"

      puts "   [Playing audio...]"
      URI.open(audio_url) do |remote_file|
        File.open(audio_file, 'wb') do |local_file|
          local_file.write(remote_file.read)
        end
      end

      system("mpg123 -q #{audio_file} 2>/dev/null")
      File.delete(audio_file) if File.exist?(audio_file)

    rescue => e
      puts "   [Error: #{e.message}]"
      puts "   [Falling back to espeak...]"
      system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.5)  # Brief pause between statements
  end

  def start
    puts "\n🎙️  Starting continuous realistic dialogue!"
    puts "    Voice: XTTS-V2 (High Quality AI)\n\n"

    speak("Hello! I'm your AI companion with a realistic voice. Let's talk!")

    loop do
      @topics.each do |topic|
        speak(topic)
      end

      speak("Let me continue our conversation with more interesting topics!")
    end
  end
end

# Catch Ctrl+C gracefully
trap("INT") do
  puts "\n\n🤖 Goodbye! It was wonderful talking with you!"
  exit
end

bot = RealisticTalkBot.new
bot.start
