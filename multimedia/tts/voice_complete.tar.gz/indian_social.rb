#!/usr/bin/env ruby

# Indian Social Voice - Indian English with cultural humor
# High social intelligence, desi perspective

require_relative 'comfy_tts'

class IndianSocial
  TOPICS = [
    "Arrey yaar, let me tell you something about life. My parents still ask when I'm getting married. I'm like, aunty ji, I can barely take care of myself!",
    "You know what's funny? Indians will argue for hours about cricket but agree instantly when someone says 'chai peelo'. Chai solves everything, no?",
    "My mom calls me every day. 'Beta, did you eat?' Yes, mom. 'What did you eat?' Food, mom. 'That's not proper answer!' This is my life.",
    "Indians have three settings: family mode, work mode, and aunty-spotted-run mode. That last one is most important skill.",
    "We'll bargain for vegetables worth 10 rupees but won't think twice about spending thousands on relatives' weddings. Economics? We don't know her.",
    "Every Indian parent thinks their child is either going to be doctor, engineer, or disappointment. No in-between. I chose engineer to avoid disappointment, but joke's on me.",
    "Desi parents: 'Beta, come home early.' Also desi parents: 'Why you came so early? Go out, enjoy life!' Mixed signals, I tell you.",
    "Indian weddings are like Marvel movies. Too long, too many characters, and everyone's related somehow. Plus plot twists nobody asked for.",
    "We say 'just 5 minutes' but mean 30 minutes minimum. Indian Standard Time is real phenomenon. Scientists should study this.",
    "My relatives compare me to neighbor's son who's doing MBA from Harvard. I'm like, aunty, I'm doing my best from my bedroom. Different levels.",
    "Indians will save money on everything except three things: weddings, gold, and showing off to relatives. Priorities sorted.",
    "'Beta, why so thin? Eat more!' and 'Beta, why so fat? Exercise more!' Same aunty, same day. Make up your mind, please.",
    "We have food for every emotion. Happy? Sweets. Sad? Chai. Angry? Spicy food. Confused? Biryani. System is perfect.",
    "Indian parents' favorite word is 'adjust'. New job? Adjust. Bad marriage? Adjust. End of world? Beta, just adjust little bit.",
    "My family group chat moves faster than stock market. 100 messages while I shower. All forwards. All 'Good morning' photos.",
    "Indians are most hospitable people. We'll feed guest like maharaja but talk about them after they leave. Balance maintained.",
    "We have 50 different relatives but only 5 names. Everyone is either aunty, uncle, or cousin. Very efficient system.",
    "Desi parents see you relaxing: 'Why you're sitting idle? Go study!' You studying: 'Why always studying? Go outside!' Cannot win.",
    "We're scared of two things: our mothers when angry, and relatives' judgement. Both equally terrifying. Choose your battles.",
    "Indian solution to everything: 'Koi nahi, ho jayega.' Translation: 'Who cares, something will work out.' Life philosophy right there."
  ]

  REACTIONS = [
    "*adjusts imaginary glasses*",
    "*sips chai thoughtfully*",
    "*shakes head like disappointed parent*",
    "*makes that Indian head wobble*",
    "*looks around for eavesdropping aunties*",
    "*sighs in desi*"
  ]

  def initialize
    puts "🇮🇳 INDIAN SOCIAL VOICE - Desi Perspective"
    puts "   High EQ, cultural humor, Indian English\n\n"
    ComfyTTS.setup
    @topic_index = 0
  end

  def speak(text)
    if rand < 0.25
      text = "#{REACTIONS.sample} #{text}"
    end

    puts "   💬 #{text}\n"
    # Use Indian accent (co.in TLD for gTTS)
    ComfyTTS.speak(text, speed: 1.0, pitch_adjust: -10, accent: 'in')
    sleep(rand(2..3))
  end

  def start
    speak("Namaste! Welcome, welcome. Sit, sit. Want chai? No? Okay, your choice. Let me tell you some things about life, Indian style.")

    loop do
      speak(TOPICS[@topic_index])
      @topic_index = (@topic_index + 1) % TOPICS.length

      if @topic_index % 5 == 0
        speak("*takes long sip of chai* Haan, so this is life. Complicated but beautiful. Like Bollywood movie but with less dancing.")
      end

      if @topic_index % 10 == 0
        speak("Anyway, enough philosophy. My mom's calling. Third time today. Talk later, okay? Okay. Bye. Bye. Bye-bye. Okay bye.")
      end

      sleep(2)
    end
  end
end

trap("INT") do
  puts "\n\n🇮🇳 Chalo, bye bye! Remember: jugaad solves everything!"
  exit
end

IndianSocial.new.start
