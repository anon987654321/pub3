#!/usr/bin/env ruby

# Automated Continuous TTS Dialogue Demo
# Bot talks continuously without user input needed

class AutoTalkBot
  def initialize
    @topics = [
      "Hello! I'm your talking companion. Let me tell you something interesting.",
      "Did you know that Ruby was created by Yukihiro Matsumoto in 1995?",
      "I love continuous conversations. It's like having a friend to talk to!",
      "Text to speech technology has come so far. We can sound almost human now!",
      "What's your favorite programming language? Mine is obviously Ruby!",
      "I could talk all day. Voice synthesis is fascinating, don't you think?",
      "Here's a fun fact: Dolphins sleep with one eye open!",
      "The sound of my voice comes from software, but the thoughts are real!",
      "I wonder what you're doing right now. Probably listening to me!",
      "Technology is amazing. We're having a conversation through code!",
      "Should I keep talking? Yes, I think I will!",
      "The year is 2025, and I'm here chatting with you. How cool is that?",
      "Let me tell you a joke: Why do programmers prefer dark mode? Light attracts bugs!",
      "I'm designed to never stop talking. That's my superpower!",
      "Communication is the bridge between confusion and clarity.",
      "Every conversation is an opportunity to learn something new.",
      "If you want me to stop, you'll have to press Control C!",
      "I'm like a radio that never turns off. Always broadcasting!",
      "Voice is powerful. It connects us in ways text never could.",
      "This is continuous dialogue. No pauses, no breaks, just talking!"
    ]
  end

  def speak(text)
    puts "\n🤖 #{text}"
    system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    sleep(1)  # Brief pause between statements
  end

  def start
    speak("Starting continuous dialogue mode! I'll keep talking!")

    loop do
      @topics.each do |topic|
        speak(topic)
      end

      speak("Let me start over and keep the conversation going!")
    end
  end
end

# Catch Ctrl+C gracefully
trap("INT") do
  puts "\n\n🤖 Goodbye! It was nice talking with you!"
  system("espeak -s 160 'Goodbye! It was nice talking with you!' 2>/dev/null")
  exit
end

bot = AutoTalkBot.new
bot.start
