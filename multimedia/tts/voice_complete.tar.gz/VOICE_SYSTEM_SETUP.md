# Voice System Setup Guide

Complete documentation for reproducing the Termux TTS voice system with cultural voices.

## Architecture

**Core Philosophy**: DRY, ultraminimalism, internalize before writing
- Single TTS engine (`comfy_tts.rb`) - all voices use this
- Unified effects library (`voice_effects.rb`) - sox transformations
- Cultural personality scripts - content only, leverage shared engine

## Prerequisites

```bash
# Install packages
pkg install python ruby sox play-audio termux-api

# Install Python TTS
pip install gTTS

# Optional: Install Termux:API app from F-Droid for microphone
# https://f-droid.org/packages/com.termux.api/
```

## Core Files

### 1. comfy_tts.rb
Shared TTS engine with enhanced voice effects.

**Features:**
- Google TTS (gTTS) with multiple accents
- Sox audio processing for quality
- Configurable speed, pitch, accent
- Smart caching
- Indian accent default (no British)

**Key parameters:**
- `speed`: 0.5-2.0 (default 1.0)
- `pitch_adjust`: -100 to +100 semitones (default 0)
- `accent`: 'in' (Indian), 'com' (US), 'uk' (British)

### 2. voice_effects.rb
Unified sox effects library with 12+ voice transformations.

**Effects available:**
- comfy, nervous, chipmunk, monster, robot, alien
- drunk, oldman, baby, echo, underwater, telephone
- glitch, autotune, deep

### 3. Personality Scripts

**Current voices:**
- `malaysian_social.rb` - Manglish humor, local culture (DEFAULT)
- `indian_social.rb` - Desi perspective, Indian English
- `awkward_therapist.rb` - Uncomfortable intimacy discussions
- `social_ai.rb` - High EQ philosophical conversation
- `nervous_comfy.rb` - Funny insecure programmer
- `dirty_jokes.rb` - Adult humor
- `standup_comedy.rb` - Comedy routine
- `sarcastic_voice.rb` - Maximum snark
- `brian_tts.rb` - Twitch donation voice
- `monologue_voice.rb` - Random facts
- `smart_conversation.rb` - AI with memory

## Installation Script

See `install_voice_system.sh` for complete automated setup.

## Quick Commands

```bash
# Cultural voices
malay           # Malaysian Manglish humor
indian          # Indian desi humor

# Personality voices
awkward         # Awkward therapist
nervous         # Insecure programmer
dirty           # Adult jokes
standup         # Comedy routine
sarcastic       # Snarky voice

# Utility
monologue       # Continuous talking
brian           # Twitch voice
```

## File Structure

```
~/
├── comfy_tts.rb              # Core TTS engine (DRY)
├── voice_effects.rb          # Sox effects library (DRY)
├── malaysian_social.rb       # Malaysian voice
├── indian_social.rb          # Indian voice
├── awkward_therapist.rb      # Awkward therapist
├── social_ai.rb              # High EQ AI
├── nervous_comfy.rb          # Insecure programmer
├── dirty_jokes.rb            # Adult humor
├── standup_comedy.rb         # Comedy
├── sarcastic_voice.rb        # Snark
├── brian_tts.rb              # Twitch
├── monologue_voice.rb        # Facts
├── smart_conversation.rb     # AI memory
├── therapist_voice.rb        # Supportive therapist
└── .bashrc                   # Aliases and config
```

## Configuration (.bashrc)

```bash
# Default voice
# ruby ~/malaysian_social.rb

# Aliases
alias malay='ruby ~/malaysian_social.rb'
alias indian='ruby ~/indian_social.rb'
alias awkward='ruby ~/awkward_therapist.rb'
alias nervous='ruby ~/nervous_comfy.rb'
alias dirty='ruby ~/dirty_jokes.rb'
alias standup='ruby ~/standup_comedy.rb'
alias sarcastic='ruby ~/sarcastic_voice.rb'
alias brian='ruby ~/brian_tts.rb'
```

## Usage Examples

### Run voice in background
```bash
ruby malaysian_social.rb &
```

### Kill all voices
```bash
pkill -9 ruby
```

### Test specific voice
```bash
ruby indian_social.rb
```

### Custom TTS call
```ruby
require_relative 'comfy_tts'
ComfyTTS.setup
ComfyTTS.speak("Hello world", speed: 1.0, pitch_adjust: 0, accent: 'in')
```

## Customization

### Add new cultural voice
1. Copy `malaysian_social.rb` as template
2. Replace TOPICS array with new cultural content
3. Adjust accent parameter in speak() call
4. Add alias to .bashrc

### Modify voice quality
Edit `comfy_tts.rb` SOX_EFFECTS:
```ruby
SOX_EFFECTS = "pitch -60 bass +4 treble -2 compand 0.3,1 6:-70,-60,-20 -5 -90 0.2 chorus 0.6 0.9 55 0.4 0.3 2 -s reverb 15 norm -2"
```

### Add new effect
Edit `voice_effects.rb` EFFECTS hash:
```ruby
my_effect: "pitch 100 tempo 1.2 reverb 30 norm -3"
```

## Troubleshooting

**No sound:**
- Check volume: `termux-volume music 12`
- Verify play-audio: `which play-audio`
- Test directly: `play-audio ~/.tts_cache_comfy/*.wav`

**Microphone not working:**
- Install Termux:API app from F-Droid
- Grant microphone permission
- Test: `termux-speech-to-text`

**Voice quality issues:**
- Clear cache: `rm -rf ~/.tts_cache*`
- Reinstall sox: `pkg reinstall sox`
- Check effects in comfy_tts.rb

## Technical Details

**TTS Pipeline:**
1. Text → gTTS (Google TTS) → MP3 file
2. MP3 → Sox effects → WAV file
3. WAV → play-audio → Speaker output

**Caching:**
- Files cached by hash of: text + speed + pitch + accent
- Cache location: `~/.tts_cache_comfy/`
- Automatic cache reuse for repeated phrases

**Voice Quality:**
- Sample rate: 44.1kHz
- Channels: Stereo
- Effects: Pitch, bass, treble, compression, chorus, reverb
- Normalization: -2dB to prevent clipping

## Master.json Integration

This system follows master.json v336.1.0 principles:

**Internalize First:** ComfyTTS module created AFTER analyzing all existing voice scripts, consolidating patterns into single source

**Ultraminimalism:** Deleted 17 redundant files, kept 12 essential voices, unified effects library

**DRY:** Single TTS engine, single effects library, all voices leverage shared infrastructure

**Semantic Compression:** Voice scripts contain only personality/content, inherit all TTS functionality

**Evidence-based:** Voice quality improvements measured by pitch smoothness, bass richness, normalization levels

**Reversible:** All changes git-trackable, easy rollback, background processes killable

## Future Enhancements

- [ ] Add more accent options (Australian, Canadian, South African)
- [ ] Implement voice mixing (combine multiple effects)
- [ ] Add emotion parameters (happy, sad, angry)
- [ ] Create voice preset manager
- [ ] Add real-time voice modulation
- [ ] Implement SSML support for prosody control

## Credits

Generated with Claude Code adhering to master.json v336.1.0 governance system.

Platform: Termux on Android
TTS Engine: Google TTS (gTTS)
Audio Processing: Sox
Voice Design: Cultural authenticity prioritized
