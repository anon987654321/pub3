#!/usr/bin/env ruby

# Joke-telling AI with Natural Voice
# Continuous comedy using Google TTS!

require 'fileutils'

class JokeTalkBot
  def initialize
    @jokes = [
      "Why do programmers prefer dark mode? Because light attracts bugs!",
      "What's a programmer's favorite hangout place? The Foo Bar!",
      "Why did the developer go broke? Because he used up all his cache!",
      "How many programmers does it take to change a light bulb? None, that's a hardware problem!",
      "Why do Java developers wear glasses? Because they don't C sharp!",
      "What do you call a programmer from Finland? Nerdic!",
      "Why did the programmer quit his job? Because he didn't get arrays!",
      "What's the object-oriented way to become wealthy? Inheritance!",
      "Why do programmers always mix up Halloween and Christmas? Because Oct 31 equals Dec 25!",
      "How do you comfort a JavaScript bug? You console it!",
      "Why did the database administrator leave his wife? She had one-to-many relationships!",
      "What's a programmer's favorite snack? Microchips with salsa!",
      "Why was the JavaScript developer sad? Because he didn't know how to 'null' his feelings!",
      "What did the router say to the doctor? It hurts when IP!",
      "Why don't programmers like nature? It has too many bugs!",
      "What's the best thing about a Boolean? Even if you're wrong, you're only off by a bit!",
      "Why did the function break up with the variable? She had constant arguments!",
      "How do you tell HTML from HTML5? Try it out in Internet Explorer. Did it work? No? It's HTML5!",
      "What do you call 8 hobbits? A hobbyte!",
      "Why do Python programmers have low self-esteem? They're constantly comparing self to others!",
      "What's a sea monster's favorite programming language? Sea Sharp!",
      "Why did the developer stay in bed? Because he had a REST API!",
      "What do you get when you cross a computer with an elephant? Lots of memory!",
      "Why are Assembly programmers always soaking wet? They work below C level!",
      "What's the second movie about a database engineer called? The SQL!",
      "Why did the scarecrow become a successful programmer? He was outstanding in his field!",
      "How do robots eat guacamole? With computer chips!",
      "Why did the PowerPoint presentation cross the road? To get to the other slide!",
      "What do you call a group of security guards in front of a Samsung store? Guardians of the Galaxy!",
      "Why was the cell phone wearing glasses? Because it lost all its contacts!",
      "Here's one: A programmer's wife tells him, go to the store and pick up a loaf of bread. If they have eggs, get a dozen. The programmer comes back with 12 loaves of bread!",
      "What did the spider do on the computer? Made a website!",
      "Why don't keyboards sleep? Because they have two shifts!",
      "What's a computer's favorite beat? An algorithm!",
      "Why did the computer show up at work late? It had a hard drive!",
      "What do you call a computer that sings? A Dell!",
      "Why was the computer cold? It left its Windows open!",
      "What do you get if you cross a computer with a lifeguard? A screensaver!",
      "Why can't computers play tennis? They try to surf the net!",
      "What's a robot's favorite type of music? Heavy metal!",
      "Why did the computer go to the doctor? It had a virus!",
      "What do you call a computer superhero? A screen saver!",
      "Why was the smartphone wearing a jacket? Because it was freezing cold storage!",
      "What kind of doctor fixes broken websites? A URLologist!",
      "Why did the tech support guy break up with his girlfriend? She had too many issues!",
      "What do computers eat for a snack? Cookies!",
      "Why did Git go to therapy? It had too many issues!",
      "What's a hacker's favorite season? Phishing season!",
      "Why don't programmers like to go outside? The sun gives them too many rays!",
      "What do you call a programmer who doesn't comment their code? An enemy of the state!"
    ]

    @responses = [
      "Wasn't that hilarious?",
      "Get it? Get it?",
      "I crack myself up!",
      "Here's another one!",
      "Wait, I've got more!",
      "This one's even better!",
      "Comedy gold, right?",
      "I'm on a roll!",
      "Let me tell you another!",
      "Ready for more laughs?",
      "You're gonna love this next one!",
      "Hold on, this one's great!",
      "Okay okay, one more!",
      "I can't stop telling jokes!",
      "Laughter is the best medicine!"
    ]

    puts "🎭 Initializing joke-telling bot..."
    check_dependencies
    @cache_dir = File.expand_path("~/.tts_cache")
    FileUtils.mkdir_p(@cache_dir)
  end

  def check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which mpg123 > /dev/null 2>&1')
      puts "Installing mpg123..."
      system('pkg install -y mpg123')
    end

    # Make sure PulseAudio is running
    unless system('pulseaudio --check 2>/dev/null')
      system('pulseaudio --start 2>/dev/null')
    end
  end

  def speak(text)
    puts "\n🤖 #{text}"

    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"

      unless File.exist?(audio_file)
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en'); tts.save('#{audio_file}')\" 2>/dev/null")
      end

      if File.exist?(audio_file)
        system("mpg123 -q #{audio_file} 2>/dev/null")
      else
        raise "Failed to generate audio"
      end

    rescue => e
      puts "   [Error: #{e.message}]"
      system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.5)
  end

  def start
    puts "\n🎭 Starting continuous joke session!"
    puts "    Voice: Google TTS (Natural Quality)\n\n"

    speak("Hello! I'm your comedy companion! Get ready to laugh!")
    sleep(1)

    joke_count = 0
    loop do
      @jokes.shuffle.each do |joke|
        speak(joke)
        sleep(1)
        speak(@responses.sample)
        sleep(1.5)

        joke_count += 1
        if joke_count % 5 == 0
          speak("That's #{joke_count} jokes so far! I've got plenty more!")
          sleep(1)
        end
      end

      speak("Let me go through my entire collection again! I never run out of jokes!")
    end
  end
end

# Catch Ctrl+C gracefully
trap("INT") do
  puts "\n\n🎭 Thanks for laughing with me! See you next time!"
  system("python3 -c \"from gtts import gTTS; tts = gTTS('Thanks for laughing with me! See you next time!', lang='en'); tts.save('/tmp/bye.mp3')\" 2>/dev/null")
  system("mpg123 -q /tmp/bye.mp3 2>/dev/null")
  File.delete("/tmp/bye.mp3") if File.exist?("/tmp/bye.mp3")
  exit
end

bot = JokeTalkBot.new
bot.start
