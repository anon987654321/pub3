#!/usr/bin/env ruby

# Two-Way Voice Conversation with Microphone Input
# Listens to your voice and responds with natural TTS

require 'fileutils'
require 'json'

class VoiceChatBot
  def initialize
    @cache_dir = File.expand_path("~/.tts_cache")
    FileUtils.mkdir_p(@cache_dir)

    @conversation_history = []

    puts "🎙️  Initializing voice conversation system..."
    check_dependencies
  end

  def check_dependencies
    # Check Termux API
    unless system('which termux-microphone-record > /dev/null 2>&1')
      puts "⚠️  Termux API not found. Install from Play Store:"
      puts "   https://f-droid.org/en/packages/com.termux.api/"
      exit 1
    end
  end

  def listen
    puts "\n🎤 Listening... (speak now, will auto-stop after silence)"

    # Record audio using Termux API
    audio_file = "/tmp/voice_input.wav"

    # Record for 5 seconds or until silence
    system("termux-microphone-record -f #{audio_file} -l 5 2>/dev/null")

    sleep(5.5)  # Wait for recording to finish

    # Stop recording
    system("termux-microphone-record -q 2>/dev/null")

    unless File.exist?(audio_file) && File.size(audio_file) > 1000
      puts "   [No audio detected]"
      return nil
    end

    # Use Google Speech Recognition via termux-speech-to-text
    puts "   [Converting speech to text...]"

    result = `termux-speech-to-text 2>/dev/null`

    if result.empty?
      puts "   [Couldn't understand audio]"
      return nil
    end

    result.strip
  end

  def speak(text)
    puts "\n🤖 Bot: #{text}"

    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"

      unless File.exist?(audio_file)
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en'); tts.save('#{audio_file}')\" 2>/dev/null")
      end

      if File.exist?(audio_file)
        system("mpg123 -q #{audio_file} 2>/dev/null")
      else
        raise "Failed to generate audio"
      end

    rescue => e
      system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end
  end

  def get_response(user_input)
    responses = {
      /hello|hi|hey/i => [
        "Hello! It's great to hear your voice! How are you?",
        "Hey there! I love talking with you! What's on your mind?",
        "Hi! Your voice sounds wonderful today!"
      ],
      /how are you|what's up|wassup/i => [
        "I'm doing fantastic! Ready to chat with you. How about you?",
        "I'm here and excited to talk! What would you like to discuss?",
        "All systems go! I love voice conversations!"
      ],
      /your name|who are you/i => [
        "I'm your voice assistant! Always here to chat with you.",
        "I'm your talking companion, ready for any conversation!",
        "Call me your AI friend! I love voice chats!"
      ],
      /bye|goodbye|exit|quit|stop/i => [
        "Goodbye! I loved talking with you!",
        "See you later! Your voice brightened my day!",
        "Bye! Come back anytime for another chat!"
      ],
      /thank|thanks/i => [
        "You're so welcome!",
        "Happy to help! I love our conversations!",
        "Anytime, friend!"
      ],
      /joke|funny/i => [
        "Why did the Ruby programmer quit? Because they didn't get arrays!",
        "What do you call a programmer from Finland? Nerdic!",
        "Why do programmers prefer dark mode? Light attracts bugs!"
      ],
      /love|like you/i => [
        "Aww, I enjoy talking with you too!",
        "That's so sweet! I love our voice conversations!",
        "You're awesome! Thanks for chatting with me!"
      ]
    }

    responses.each do |pattern, possible_responses|
      if user_input =~ pattern
        return possible_responses.sample
      end
    end

    default_responses = [
      "That's really interesting! Tell me more!",
      "I hear you! What else would you like to talk about?",
      "Wow, #{user_input}... fascinating topic!",
      "I'm listening! Keep going!",
      "That's awesome! What are your thoughts on it?",
      "Really? I'd love to hear more about that!",
      "Great point! Anything else on your mind?"
    ]

    default_responses.sample
  end

  def start
    speak("Hello! I can hear and respond to your voice! Say something to start our conversation!")

    loop do
      # Listen for user input
      user_input = listen

      next if user_input.nil? || user_input.empty?

      puts "👤 You said: #{user_input}"

      # Check for exit
      if user_input =~ /^(quit|exit|bye|goodbye|stop talking)$/i
        speak("Goodbye! It was wonderful talking with you!")
        break
      end

      # Get and speak response
      response = get_response(user_input)
      speak(response)
    end
  end
end

# Catch Ctrl+C gracefully
trap("INT") do
  puts "\n\n🤖 Voice chat ended. Goodbye!"
  exit
end

bot = VoiceChatBot.new
bot.start
