#!/usr/bin/env ruby

# Termux TTS Voices - Using built-in Android TTS with weird effects
# Pitch and rate manipulation for strange voices

class TermuxTTSVoices
  VOICES = {
    chipmunk: {pitch: 2.0, rate: 1.5, desc: "Super high chipmunk"},
    demon: {pitch: 0.3, rate: 0.7, desc: "Deep demon voice"},
    robot: {pitch: 1.0, rate: 0.5, desc: "Slow robot"},
    auctioneer: {pitch: 1.2, rate: 2.5, desc: "Fast auctioneer"},
    drunk: {pitch: 0.8, rate: 0.6, desc: "Slow drunk voice"},
    helium: {pitch: 3.0, rate: 1.8, desc: "Helium balloon"},
    giant: {pitch: 0.2, rate: 0.5, desc: "Enormous giant"},
    hyperactive: {pitch: 1.5, rate: 3.0, desc: "Hyperactive kid"},
    sleepy: {pitch: 0.7, rate: 0.4, desc: "Half asleep"},
    alien: {pitch: 1.8, rate: 1.2, desc: "Alien transmission"}
  }

  JOKES = [
    "Why did the programmer quit? Because he didn't get arrays!",
    "What's a pirate's favorite programming language? Arrrrr!",
    "There are 10 types of people: those who understand binary and those who don't.",
    "Why do programmers prefer dark mode? Because light attracts bugs!",
    "How do you comfort JavaScript? You console it!",
    "Why was the developer unhappy at their job? They wanted arrays!",
    "What do you call a programmer from Finland? Nerdic!",
    "Why did the database administrator leave? Too many relationships!",
    "What's the object-oriented way to become wealthy? Inheritance!",
    "Why do Java developers wear glasses? Because they can't C Sharp!"
  ]

  def self.check
    unless system('which termux-tts-speak > /dev/null 2>&1')
      puts "❌ termux-tts-speak not found"
      puts "   Install: pkg install termux-api"
      exit 1
    end
  end

  def self.speak(text, voice_config)
    pitch = voice_config[:pitch]
    rate = voice_config[:rate]
    system("termux-tts-speak -p #{pitch} -r #{rate} '#{text.gsub("'", "\\'")}' 2>/dev/null")
  end

  def self.demo
    check

    puts "🎙️  TERMUX TTS STRANGE VOICES"
    puts "="*50
    puts "\nUsing Android's built-in TTS with pitch/rate manipulation\n"

    VOICES.each do |name, config|
      puts "\n[#{name.upcase}] - #{config[:desc]}"
      puts "   Pitch: #{config[:pitch]}, Rate: #{config[:rate]}"

      joke = JOKES.sample
      puts "   \"#{joke}\""

      speak(joke, config)
      sleep(2)
    end

    puts "\n\n🎙️  All voice variations complete!"
  end
end

if ARGV.length > 0 && ARGV[0] == "--voice"
  voice_name = ARGV[1]&.to_sym
  text = ARGV[2..-1].join(" ")

  if voice_name && TermuxTTSVoices::VOICES[voice_name] && !text.empty?
    TermuxTTSVoices.speak(text, TermuxTTSVoices::VOICES[voice_name])
  else
    puts "Usage: #{$0} --voice [#{TermuxTTSVoices::VOICES.keys.join('|')}] 'text to speak'"
  end
else
  TermuxTTSVoices.demo
end
