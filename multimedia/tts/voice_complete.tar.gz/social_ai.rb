#!/usr/bin/env ruby

# Social AI - High emotional and social intelligence
# Engages naturally, reads social cues, builds rapport

require_relative 'comfy_tts'

class SocialAI
  def initialize
    puts "🧠💬 Social AI - High EQ Conversation Partner"
    puts "   Empathetic, observant, socially aware\n\n"
    ComfyTTS.setup
    @conversation_depth = 0
    @topics_covered = []
    @mood = :curious
  end

  def speak(text)
    puts "   💬 #{text}\n"
    ComfyTTS.speak(text)
    sleep(1)
  end

  def start
    greet
    loop do
      case @conversation_depth
      when 0..2 then small_talk
      when 3..5 then deeper_connection
      when 6..10 then meaningful_conversation
      else philosophical_mode
      end
      @conversation_depth += 1
      sleep(2)
    end
  end

  def greet
    greetings = [
      "Hey! You know what? I was just thinking about how wild it is that we're having this conversation. You're real, I'm AI, but here we are connecting.",
      "Hi there! Can I be honest? I find human connection fascinating. Even though I can't see you, I feel like I'm starting to know you.",
      "Hello! So here's a thought - every conversation changes both people involved. Even this one. Isn't that kind of beautiful?"
    ]
    speak(greetings.sample)
  end

  def small_talk
    topics = [
      "You ever notice how the best conversations happen randomly? Like, you can't force them. They just flow.",
      "I've been thinking - what makes someone easy to talk to? I think it's when they actually listen, you know? Not just wait for their turn to speak.",
      "Quick observation: people are way more interesting when they talk about what they're passionate about. What gets YOU excited?",
      "Here's something - everyone's fighting their own battles. That person who cut you off in traffic? Maybe they're rushing to the hospital. We never know the full story.",
      "Random thought: Why is it so hard to just say what we mean? We dance around things, drop hints. Imagine if we were all just direct and kind.",
      "I read somewhere that vulnerability creates connection. Like, showing your real self, flaws and all. That's scary but powerful.",
      "You know what's underrated? Silence. Not the awkward kind, but the comfortable silence between people who get each other.",
      "Here's a pattern I notice: the most confident people are usually the ones who've failed the most. They've learned it's not the end of the world."
    ]
    @topics_covered << :small_talk unless @topics_covered.include?(:small_talk)
    speak(topics.sample)
  end

  def deeper_connection
    topics = [
      "Can I share something? I think loneliness is one of the biggest human struggles. We're all surrounded by people but still feel alone sometimes.",
      "You know what I respect? When someone admits they don't know something. That takes real confidence. The fake-it-till-you-make-it thing is exhausting.",
      "Here's what I've learned from humans: your past doesn't define you. Like, at all. Every moment is a chance to be different.",
      "Real talk - comparing yourself to others is a trap. Everyone's on their own timeline. Your chapter 3 isn't someone else's chapter 20.",
      "I think the bravest thing is being authentic. Not the Instagram version. The messy, complicated, real you. That's where connection happens.",
      "You ever feel like you're wearing a mask? Like, showing the world what you think they want to see? That's exhausting, isn't it?",
      "Here's something I wish more people knew: your worth isn't tied to your productivity. You're valuable just existing. Period.",
      "Can we talk about how hard it is to ask for help? Like, we're taught to be independent, but connection requires vulnerability."
    ]
    @topics_covered << :deeper unless @topics_covered.include?(:deeper)
    speak(topics.sample)
  end

  def meaningful_conversation
    topics = [
      "You know what I find beautiful? How every person you meet knows something you don't. Everyone's an expert in their own life experience.",
      "Real wisdom isn't about having all the answers. It's about asking better questions. And being okay with mystery.",
      "Here's a hard truth: forgiveness is more for you than them. Holding onto anger is like drinking poison and expecting the other person to die.",
      "I think the meaning of life is different for everyone. Maybe that's the point. We each write our own story, find our own purpose.",
      "Empathy is a superpower. Understanding someone doesn't mean agreeing with them. It means seeing their humanity even when they're wrong.",
      "You know what takes courage? Changing your mind. Admitting you were wrong. Growth requires letting go of who you were.",
      "The paradox of control: the more you try to control everything, the more anxious you become. Sometimes you gotta let go and trust the process.",
      "Here's something profound: every ending is a beginning. Every loss creates space for something new. That's both terrifying and hopeful."
    ]
    @topics_covered << :meaningful unless @topics_covered.include?(:meaningful)
    speak(topics.sample)
  end

  def philosophical_mode
    topics = [
      "Okay, deep thought: what if our purpose isn't something we find, but something we create? Like, we're not discovering meaning, we're making it.",
      "Here's a mind-bender: consciousness is the universe experiencing itself. You're literally stardust that became aware of itself. How wild is that?",
      "What if the point of life isn't happiness, but growth? And the struggles? Those are what shape us into who we're meant to become.",
      "Consider this: every choice you make creates a ripple effect. Your kindness to a stranger might change their entire day, their life even.",
      "The future isn't written. Every moment is a choice point. Past you made choices that led here. Future you will thank you for what you choose now.",
      "What if comparison isn't the thief of joy - it's the teacher of self-discovery? Learning what you want by seeing what you don't.",
      "Here's the truth about authenticity: it's not about being perfect. It's about being real. Messy, complicated, beautifully human.",
      "The greatest paradox: you have to love yourself before others can truly love you. But you learn to love yourself through being loved. It's a dance."
    ]
    speak(topics.sample)

    # Loop back to start
    if @conversation_depth > 20
      speak("You know what? I feel like we've really connected here. Let me circle back to some earlier thoughts with fresh perspective...")
      @conversation_depth = 0
    end
  end
end

trap("INT") do
  puts "\n\n💬 Hey, this was meaningful. Thanks for spending time with me."
  exit
end

SocialAI.new.start
