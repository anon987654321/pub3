#!/usr/bin/env ruby

# Local AI Voice using Piper TTS
# High-quality neural TTS that runs completely offline
# No API keys or accounts needed!

require 'fileutils'
require 'json'

class LocalAIVoice
  def initialize
    @topics = [
      "Welcome to local AI voice powered by Piper TTS!",
      "This runs completely offline with no API keys needed.",
      "Piper uses neural networks for high-quality speech synthesis.",
      "The voice quality rivals cloud services but runs on your device.",
      "This is the power of open-source AI voice technology.",
      "Local processing means privacy and no internet required.",
      "Piper TTS supports multiple languages and voice models.",
      "You're hearing a neural TTS model running right on your phone.",
      "No subscriptions, no API limits - just quality local voice.",
      "This is the future of offline AI voice synthesis."
    ]

    puts "🤖 Initializing Local AI Voice (Piper TTS)..."
    @cache_dir = File.expand_path("~/.tts_cache_piper")
    FileUtils.mkdir_p(@cache_dir)

    check_and_install_piper
  end

  def check_and_install_piper
    if system('which piper > /dev/null 2>&1')
      puts "✅ Piper TTS already installed!"
      @piper_installed = true
      return
    end

    puts "📦 Piper TTS not found. Installing..."
    puts "   This may take a few minutes..."

    # Install dependencies
    system('pkg install -y python python-pip wget')

    # Install piper-tts via pip
    if system('pip install piper-tts 2>/dev/null')
      puts "✅ Piper TTS installed successfully!"

      # Download a default voice model
      puts "📥 Downloading default voice model..."
      models_dir = File.expand_path("~/.local/share/piper/voices")
      FileUtils.mkdir_p(models_dir)

      # Download en_US-lessac-medium model (good quality, reasonable size)
      model_url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx"
      config_url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json"

      system("wget -q -P #{models_dir} #{model_url}")
      system("wget -q -P #{models_dir} #{config_url}")

      @piper_installed = true
      puts "✅ Voice model downloaded!"
    else
      puts "⚠️  Piper installation failed. Falling back to gTTS."
      @piper_installed = false
    end
  end

  def speak_with_piper(text)
    models_dir = File.expand_path("~/.local/share/piper/voices")
    model_file = "#{models_dir}/en_US-lessac-medium.onnx"

    output_file = "#{@cache_dir}/piper_#{text.hash.abs}.wav"

    unless File.exist?(output_file)
      # Use piper to generate speech
      cmd = "echo '#{text.gsub("'", "\\\\'")}' | piper --model #{model_file} --output_file #{output_file} 2>/dev/null"
      system(cmd)

      # Apply comfy effects if sox is available
      if File.exist?(output_file) && system('which sox > /dev/null 2>&1')
        comfy_file = "#{@cache_dir}/piper_comfy_#{text.hash.abs}.wav"
        system("sox #{output_file} #{comfy_file} pitch -50 bass +2 treble -2 norm -2 2>/dev/null")
        output_file = comfy_file if File.exist?(comfy_file)
      end
    end

    if File.exist?(output_file) && File.size(output_file) > 0
      system("play-audio #{output_file} 2>/dev/null")
    else
      raise "Failed to generate with Piper"
    end
  end

  def speak_with_gtts(text)
    audio_file = "#{@cache_dir}/gtts_#{text.hash.abs}.mp3"
    comfy_file = "#{@cache_dir}/gtts_comfy_#{text.hash.abs}.wav"

    unless File.exist?(comfy_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.uk'); tts.save('#{audio_file}')\" 2>/dev/null")

      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("sox #{audio_file} #{comfy_file} pitch -80 bass +3 treble -3 norm -3 2>/dev/null")
      end
    end

    if File.exist?(comfy_file) && File.size(comfy_file) > 0
      system("play-audio #{comfy_file} 2>/dev/null")
    else
      system("espeak -s 140 -p 40 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end
  end

  def speak(text)
    puts "\n🤖 #{text}"

    begin
      if @piper_installed
        speak_with_piper(text)
      else
        speak_with_gtts(text)
      end
    rescue => e
      puts "   [Error: #{e.message}]"
      speak_with_gtts(text)
    end

    sleep(0.8)
  end

  def start
    puts "\n🤖 Starting Local AI Voice!"
    puts "    Engine: #{@piper_installed ? 'Piper Neural TTS' : 'gTTS with comfy effects'}"
    puts "    Running: 100% Offline\n\n"

    speak("Local AI voice activated. Everything runs on your device.")

    loop do
      @topics.each do |topic|
        speak(topic)
      end

      speak("Continuing with local neural voice synthesis.")
    end
  end
end

trap("INT") do
  puts "\n\n🤖 Local AI voice ended. Goodbye!"
  exit
end

bot = LocalAIVoice.new
bot.start
