#!/usr/bin/env ruby

# Dirty Jokes Voice - Raunchy adult humor, clear voice
# Not for kids. Actually funny.

require 'fileutils'

class DirtyVoice
  CACHE_DIR = File.expand_path("~/.tts_cache_dirty")
  # Smooth voice, no echo, just good delivery
  SOX_EFFECTS = "pitch -30 bass +1 norm -3"

  def self.setup
    FileUtils.mkdir_p(CACHE_DIR)
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end
  end

  def self.speak(text)
    setup
    text_hash = text.hash.abs.to_s
    audio_file = "#{CACHE_DIR}/speech_#{text_hash}.mp3"
    dirty_file = "#{CACHE_DIR}/dirty_#{text_hash}.wav"

    unless File.exist?(dirty_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com'); tts.save('#{audio_file}')\" 2>/dev/null")
      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("sox #{audio_file} #{dirty_file} #{SOX_EFFECTS} 2>/dev/null")
      end
    end

    system("play-audio #{dirty_file} 2>/dev/null") if File.exist?(dirty_file) && File.size(dirty_file) > 0
  end
end

# RAUNCHY ADULT JOKES
JOKES = [
  "What's the difference between your job and your wife? After five years, your job still sucks.",
  "Why do women fake orgasms? Because they think we care.",
  "My girlfriend said she wanted to try anal. I said okay, but only if I can go first.",
  "Sex is like math. You add the bed, subtract the clothes, divide the legs, and pray you don't multiply.",
  "What do you call a cheap circumcision? A rip-off.",
  "I'm not saying she's easy, but her password is 1-2-3-4.",
  "What's the difference between a G-spot and a golf ball? A guy will actually search for a golf ball.",
  "My wife asked if she could have a little peace and quiet while she cooked dinner. So I took the batteries out of the smoke alarm.",
  "What do you call a lesbian dinosaur? Lickalotapuss.",
  "Why don't witches wear panties? Better grip on the broomstick.",
  "I asked my partner if I was the best they ever had. They said I was in the top five.",
  "What's long, hard, and has cum in it? A cucumber.",
  "Why do men get their great ideas in bed? Because they're plugged into a genius.",
  "My girlfriend thinks I'm a stalker. Well, she's not my girlfriend yet.",
  "What's the difference between your penis and your paycheck? You don't have to beg your wife to blow your paycheck.",
  "I asked my wife what she wanted for her birthday. She said nothing would make her happier than a diamond necklace. So I got her nothing.",
  "What do you call a guy with a small dick? Justin.",
  "Why did God give men penises? So they'd have at least one way to shut a woman up.",
  "My wife caught me cross-dressing. Now I can't see her anymore. The dress is too long.",
  "What's six inches long and makes women go crazy? A hundred dollar bill."
]

if ARGV.length > 0
  DirtyVoice.speak(ARGV.join(" "))
else
  puts "🔞 DIRTY JOKES MODE - Adults Only!"
  puts "="*50
  JOKES.shuffle.each_with_index do |joke, i|
    puts "\n[Joke #{i+1}]"
    puts "   #{joke}"
    DirtyVoice.speak(joke)
    sleep(2)
    break if i >= 9  # Tell 10 jokes
  end
  puts "\n🔞 You've been warned!"
end
