#!/usr/bin/env ruby

# Shared TTS module with comfy voice effects
# Extracted from comfy_voice.rb, natural_talk.rb patterns
# DRY principle: single source for TTS across all voice scripts

require 'fileutils'

module ComfyTTS
  CACHE_DIR = File.expand_path("~/.tts_cache_comfy")
  # Enhanced effects: smoother pitch, richer bass, better compression, wider stereo
  SOX_EFFECTS = "pitch -60 bass +4 treble -2 compand 0.3,1 6:-70,-60,-20 -5 -90 0.2 chorus 0.6 0.9 55 0.4 0.3 2 -s reverb 15 norm -2"

  def self.check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end

    unless system('which sox > /dev/null 2>&1')
      puts "Installing sox..."
      system('pkg install -y sox')
    end
  end

  def self.setup
    check_dependencies
    FileUtils.mkdir_p(CACHE_DIR)
  end

  def self.speak(text, speed: 1.0, pitch_adjust: 0, accent: 'in')
    text_hash = "#{text}#{speed}#{pitch_adjust}#{accent}".hash.abs.to_s
    audio_file = "#{CACHE_DIR}/speech_#{text_hash}.mp3"
    comfy_file = "#{CACHE_DIR}/comfy_#{text_hash}.wav"

    unless File.exist?(comfy_file)
      # Use Indian English by default, US as fallback
      tld = accent
      slow_flag = speed < 0.8 ? 'True' : 'False'

      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.#{tld}', slow=#{slow_flag}); tts.save('#{audio_file}')\" 2>/dev/null")

      if File.exist?(audio_file) && File.size(audio_file) > 0
        # Apply speed and pitch adjustments
        custom_effects = SOX_EFFECTS.dup
        custom_effects = "tempo #{speed} " + custom_effects if speed != 1.0
        custom_effects = custom_effects.gsub("pitch -60", "pitch #{-60 + pitch_adjust}") if pitch_adjust != 0

        system("sox #{audio_file} #{comfy_file} #{custom_effects} 2>/dev/null")
      end
    end

    if File.exist?(comfy_file) && File.size(comfy_file) > 0
      system("play-audio #{comfy_file} 2>/dev/null")
      true
    else
      false
    end
  end
end
