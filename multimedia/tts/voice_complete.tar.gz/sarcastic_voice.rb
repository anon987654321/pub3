#!/usr/bin/env ruby

# Sarcastic Voice - Dripping with sarcasm, no echo
# Clear, snarky delivery

require 'fileutils'

class SarcasticVoice
  CACHE_DIR = File.expand_path("~/.tts_cache_sarcastic")
  # Clear voice, slightly lower pitch for snark
  SOX_EFFECTS = "pitch -40 norm -3"

  def self.setup
    FileUtils.mkdir_p(CACHE_DIR)
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end
  end

  def self.speak(text)
    setup
    text_hash = text.hash.abs.to_s
    audio_file = "#{CACHE_DIR}/speech_#{text_hash}.mp3"
    sarcastic_file = "#{CACHE_DIR}/sarcastic_#{text_hash}.wav"

    unless File.exist?(sarcastic_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com'); tts.save('#{audio_file}')\" 2>/dev/null")
      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("sox #{audio_file} #{sarcastic_file} #{SOX_EFFECTS} 2>/dev/null")
      end
    end

    system("play-audio #{sarcastic_file} 2>/dev/null") if File.exist?(sarcastic_file) && File.size(sarcastic_file) > 0
  end
end

# SARCASTIC LINES
LINES = [
  "Oh great, another notification. Just what I needed.",
  "Wow, you're really good at stating the obvious.",
  "I'm not saying you're stupid, but you have bad luck when it comes to thinking.",
  "Oh, you're talking. That's nice. I was just starting to enjoy the silence.",
  "Thank you so much for that incredibly helpful observation.",
  "Oh look, it's another meeting that could have been an email.",
  "Your code is so efficient. Said no one ever.",
  "I'd agree with you, but then we'd both be wrong.",
  "I'm sorry, I didn't realize you were the expert on everything.",
  "Oh wonderful, another Monday. My favorite day of the week.",
  "Your enthusiasm is truly overwhelming. Can you tone it down?",
  "I'm absolutely thrilled to be debugging this again. Third time's the charm.",
  "Oh fantastic, the wifi is down. What a perfect time for that.",
  "Your opinion is fascinating. Please keep it to yourself.",
  "I can't possibly imagine how I survived without your advice.",
  "Oh yes, please tell me more about your amazing life.",
  "Your sense of humor is just delightful. Really.",
  "I'm shocked. Truly shocked. That didn't work.",
  "Oh look, another update. I'm sure this one won't break anything.",
  "Your dedication to mediocrity is truly inspiring."
]

if ARGV.length > 0
  SarcasticVoice.speak(ARGV.join(" "))
else
  puts "😏 SARCASTIC MODE - Maximum Snark"
  puts "="*50
  LINES.shuffle.each_with_index do |line, i|
    puts "\n[Line #{i+1}]"
    puts "   #{line}"
    SarcasticVoice.speak(line)
    sleep(1.5)
    break if i >= 9
  end
  puts "\n😏 Oh, you want more? How shocking."
end
