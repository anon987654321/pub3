#!/usr/bin/env ruby

# Malaysian Social Voice - Manglish with local culture
# High social intelligence, Malaysian perspective

require_relative 'comfy_tts'

class MalaysianSocial
  TOPICS = [
    "Wah lau eh, you know or not, Malaysians can spot another Malaysian anywhere in the world. Just mention nasi lemak and see who turns around!",
    "Traffic jam in KL is no joke lah. Morning also jam, evening also jam, weekend also jam. When not jam? Only 3am maybe.",
    "Mamak culture is peak Malaysian. Where else can you lepak until 2am eating roti canai and watching football? Nowhere, I tell you.",
    "We have 4 languages minimum. English, Malay, Mandarin, Tamil, plus our dialects. Very efficient when you want to gossip without someone understanding!",
    "Malaysian weather got only two types: hot until die, or raining until flood. No in-between. Sometimes both same time also can!",
    "You haven't experienced Malaysian hospitality until aunty forces you to eat until cannot walk. 'Makan! Makan!' is our love language.",
    "Malaysians are experts at queuing for food. New restaurant opening? Queue 3 hours no problem. Must try what! Instagram stories won't post itself.",
    "We say 'can' for everything. 'Can or not?' 'Can can!' 'Cannot lah!' Most versatile word in Manglish vocabulary.",
    "Public holiday falls on weekend? Whole country sad together. Cuti-cuti Malaysia also need proper rest day, what!",
    "Malaysians will fight over best nasi lemak, best char kuay teow, best rendang. But mention durian and suddenly everyone united in loving or hating.",
    "Our driving very special. Hazard lights means thank you, means sorry, means parking here, means everything. Universal signal!",
    "Touch and Go card always no money when you reach toll. Every single time! It's like Malaysian rite of passage.",
    "We add 'lah' to everything lah. Cannot remove lah. Part of identity already lah. Even when speak English also must add lah!",
    "Malaysians are very creative with parking. Sidewalk also can park, double park also standard, triple park with phone number on dashboard. Innovation!",
    "Food is our religion. Miss one meal? Whole family concerned. 'You haven't eat ah? Aiyo, come come, I cook for you!' No escape.",
    "Mamak restaurant menu thicker than college textbook. 100 pages of food choices. Still end up ordering same thing every time.",
    "We're very efficient people. One hand eat, one hand phone, somehow still can talk to friends. Multitasking champions!",
    "Malaysian parents very contradicting. 'Study hard!' but also 'Why never help with housework?' Cannot win one!",
    "Pasar malam is where we display our bargaining skills. Mark up 200%, we bargain down 150%. Fair game what!",
    "Malaysians very patriotic during badminton tournaments. Suddenly everyone expert in sports analysis. 'Aiyo, why he play like that!'"
  ]

  REACTIONS = [
    "*wipes sweat from humidity*",
    "*checks if rain starting*",
    "*craves teh tarik suddenly*",
    "*does the Malaysian head nod*",
    "*looks around for mamak*",
    "*fans self dramatically*"
  ]

  def initialize
    puts "🇲🇾 MALAYSIAN SOCIAL VOICE - Manglish Culture"
    puts "   High EQ, local humor, truly Malaysian\n\n"
    ComfyTTS.setup
    @topic_index = 0
  end

  def speak(text)
    if rand < 0.3
      text = "#{REACTIONS.sample} #{text}"
    end

    puts "   💬 #{text}\n"
    # Use Indian accent as closest to Malaysian English
    ComfyTTS.speak(text, speed: 1.05, pitch_adjust: -5, accent: 'in')
    sleep(rand(2..3))
  end

  def start
    speak("Apa khabar! Welcome lah! Come, sit sit. You want kopi o or teh tarik? Aiyo, just say lah, don't be shy!")

    loop do
      speak(TOPICS[@topic_index])
      @topic_index = (@topic_index + 1) % TOPICS.length

      if @topic_index % 5 == 0
        speak("Walao eh, talk until mouth dry already. Time for teh tarik break! But before that, let me tell you more things...")
      end

      if @topic_index % 10 == 0
        speak("Okay lah, I go first. Later traffic jam cannot go home. You take care ah! Don't forget eat! Bye bye!")
      end

      sleep(2)
    end
  end
end

trap("INT") do
  puts "\n\n🇲🇾 Okay lah, see you later! Jangan lupa makan!"
  exit
end

MalaysianSocial.new.start
