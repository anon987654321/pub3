#!/usr/bin/env ruby

# Brian TTS - Using StreamElements API
# The famous Twitch donation voice with funny sounds

require 'net/http'
require 'uri'
require 'cgi'
require 'fileutils'

class BrianTTS
  CACHE_DIR = File.expand_path("~/.tts_cache_brian")
  API_URL = "https://api.streamelements.com/kappa/v2/speech"

  def self.setup
    FileUtils.mkdir_p(CACHE_DIR)
  end

  def self.speak(text)
    setup
    text_hash = text.hash.abs.to_s
    audio_file = "#{CACHE_DIR}/brian_#{text_hash}.mp3"

    unless File.exist?(audio_file)
      puts "   [Generating Brian TTS...]"
      url = "#{API_URL}?voice=Brian&text=#{CGI.escape(text)}"

      begin
        uri = URI(url)
        response = Net::HTTP.get_response(uri)

        if response.code == "200"
          File.open(audio_file, 'wb') { |f| f.write(response.body) }
        else
          puts "   Error: API returned #{response.code}"
          return false
        end
      rescue => e
        puts "   Error: #{e.message}"
        return false
      end
    end

    if File.exist?(audio_file) && File.size(audio_file) > 0
      system("play-audio #{audio_file} 2>/dev/null")
      true
    else
      false
    end
  end
end

# FUNNY BRIAN TTS LINES WITH TRICKS
BRIAN_JOKES = [
  "777777777 My name is Brian and I talk really fast when you spam numbers",
  "I'm not drunk, you're drunk! Hic hic hic",
  "HAHAHAHAHAHA that's so funny I can't stop laughing",
  "What the hell is happening right now?",
  "Oh my god oh my god this is crazy",
  "YESYESYESYESYES I love this song!",
  "Nonononono this can't be happening",
  "Brrrrrrr goes the money printer brrrrrrr",
  "PEW PEW PEW pew pew take that!",
  "Subscribe and donate or I'll be sad",
  "Why did the chicken cross the road? To get away from your bad jokes!",
  "I am the voice of a thousand Twitch streams",
  "Your mom is so nice, she donated to charity",
  "Error four oh four, brain not found",
  "This stream is brought to you by, me, Brian",
  "Wubwubwubwubwub drop the bass wubwubwub",
  "Ring ring ring banana phone",
  "All your base are belong to us",
  "It's over nine thousand!",
  "F in the chat boys F F F F"
]

# SOUND EFFECTS USING BRIAN
BRIAN_SFX = [
  "7777777777777777",
  "LALALALALALALA",
  "BRRRRRRRRRRR",
  "NG NG NG NG NG",
  "AHAHAHAHAHAHAHA",
  "Meow meow meow meow",
  "Woof woof bark bark bark",
  "BOOM BOOM BOOM",
  "Beep boop beep boop boop",
  "Honk honk hoooooonk"
]

if ARGV.length > 0
  BrianTTS.speak(ARGV.join(" "))
else
  puts "🎙️  BRIAN TTS MODE - Twitch Donation Voice"
  puts "="*50

  puts "\n😂 FUNNY LINES:"
  BRIAN_JOKES.sample(5).each_with_index do |joke, i|
    puts "\n[#{i+1}] #{joke}"
    BrianTTS.speak(joke)
    sleep(2)
  end

  puts "\n\n🔊 SOUND EFFECTS:"
  BRIAN_SFX.sample(3).each do |sfx|
    puts "\n   #{sfx}"
    BrianTTS.speak(sfx)
    sleep(1)
  end

  puts "\n\n🎙️  Brian TTS demo complete!"
end
