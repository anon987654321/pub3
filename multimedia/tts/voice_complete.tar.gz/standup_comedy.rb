#!/usr/bin/env ruby

# Standup Comedy Voice - Adult humor, no echo, clear voice
# Real comedy, not kid stuff

require 'fileutils'

class StandupVoice
  CACHE_DIR = File.expand_path("~/.tts_cache_standup")
  # Clear voice with slight effects - NO ECHO
  SOX_EFFECTS = "pitch -50 bass +2 norm -3"

  def self.setup
    FileUtils.mkdir_p(CACHE_DIR)
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end
  end

  def self.speak(text)
    setup
    text_hash = text.hash.abs.to_s
    audio_file = "#{CACHE_DIR}/speech_#{text_hash}.mp3"
    standup_file = "#{CACHE_DIR}/standup_#{text_hash}.wav"

    unless File.exist?(standup_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com'); tts.save('#{audio_file}')\" 2>/dev/null")
      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("sox #{audio_file} #{standup_file} #{SOX_EFFECTS} 2>/dev/null")
      end
    end

    system("play-audio #{standup_file} 2>/dev/null") if File.exist?(standup_file) && File.size(standup_file) > 0
  end
end

# ACTUAL FUNNY ADULT JOKES
JOKES = [
  "My therapist says I have a preoccupation with vengeance. We'll see about that.",
  "I told my wife she was drawing her eyebrows too high. She looked surprised.",
  "I'm not saying my wife is ugly, but on our wedding day, the photographer kept asking her to stand behind me.",
  "My girlfriend said I'm too controlling. I didn't say she could talk.",
  "I asked my wife if I was the only one she'd been with. She said yes, all the others were nines and tens.",
  "Marriage is like a deck of cards. At first, all you need is two hearts and a diamond. By the end, you wish you had a club and a spade.",
  "My wife told me to stop impersonating a flamingo. I had to put my foot down.",
  "I'm not saying I'm Batman, but have you ever seen me and Batman in the same room together?",
  "I used to be addicted to the hokey pokey, but I turned myself around.",
  "My wife accused me of being immature. I told her to get out of my fort.",
  "I told my psychiatrist I think I'm a dog. He told me to get off his couch.",
  "My girlfriend is like the square root of negative 100. She's a perfect 10, but completely imaginary.",
  "I'm reading a book about anti-gravity. It's impossible to put down.",
  "I tried to catch fog yesterday. Mist.",
  "Why don't scientists trust atoms? Because they make up everything.",
  "I stayed up all night wondering where the sun went. Then it dawned on me.",
  "My wife said I should do lunges to stay in shape. That would be a big step forward.",
  "I have a fear of speed bumps. But I'm slowly getting over it.",
  "My friend asked me to help him round up his 37 sheep. I said 40.",
  "I used to hate facial hair, but then it grew on me.",
  "RIP boiling water. You will be mist.",
  "My wife says I'm too competitive. I thought about it and she's right. I win.",
  "I got fired from the keyboard factory. I wasn't putting in enough shifts.",
  "My boss told me to have a good day. So I went home.",
  "I'm on a whiskey diet. I've lost three days already."
]

if ARGV.length > 0
  StandupVoice.speak(ARGV.join(" "))
else
  puts "🎤 STANDUP COMEDY MODE - Adult Humor Edition"
  puts "="*50
  JOKES.shuffle.each_with_index do |joke, i|
    puts "\n[Joke #{i+1}]"
    puts "   #{joke}"
    StandupVoice.speak(joke)
    sleep(2)
    break if i >= 9  # Tell 10 jokes then stop
  end
  puts "\n🎤 That's all folks! Tip your waitress!"
end
