#!/usr/bin/env ruby

# Therapist Voice - Calm, soothing, supportive female therapist
# Perfect for therapeutic conversations

require_relative 'comfy_tts'

class TherapistVoice
  RESPONSES = {
    /sad|depressed|down|upset/i => [
      "I hear that you're feeling sad. That's completely valid. Can you tell me more about what's making you feel this way?",
      "It sounds like you're going through a difficult time. Your feelings are important and I'm here to listen.",
      "Depression is really hard. You're not alone in this. What's been weighing on you?"
    ],
    /anxious|anxiety|worried|stress/i => [
      "Anxiety can be overwhelming. Let's take a deep breath together. What specifically is making you feel anxious?",
      "I can hear the worry in your words. It's okay to feel anxious. Let's talk through what's bothering you.",
      "Stress affects us all differently. You're doing the right thing by talking about it. What's on your mind?"
    ],
    /angry|mad|frustrated/i => [
      "Your anger is valid. It's okay to feel upset. What happened that made you feel this way?",
      "I can sense your frustration. Those feelings are real and important. Tell me more.",
      "Anger often comes from feeling hurt or unheard. Help me understand what you're going through."
    ],
    /happy|good|great|better/i => [
      "I'm so glad to hear you're feeling better! What's been going well for you?",
      "That's wonderful! It's important to celebrate the good moments. Tell me about it!",
      "Your happiness matters. I love hearing positive updates from you!"
    ],
    /scared|afraid|fear/i => [
      "Fear is a natural emotion. You're safe here to talk about what's scaring you.",
      "I can hear that you're afraid. That takes courage to admit. What's making you feel this way?",
      "Being scared is okay. Let's work through this together. What's frightening you?"
    ],
    /lonely|alone|isolated/i => [
      "Loneliness is one of the hardest feelings. I want you to know I'm here with you right now.",
      "Feeling isolated is so difficult. You're not as alone as you feel. Tell me what's happening.",
      "I hear you. Being lonely hurts. Let's talk about ways to help you feel more connected."
    ],
    /tired|exhausted|drained/i => [
      "It sounds like you're carrying a heavy load. Being tired isn't just physical. What's draining your energy?",
      "Exhaustion is your body and mind telling you something. Let's explore what's wearing you down.",
      "You deserve rest and care. Tell me what's been taking so much out of you."
    ],
    /relationship|partner|boyfriend|girlfriend|husband|wife/i => [
      "Relationships can be complex. Tell me what's happening between you two.",
      "It sounds like your relationship is on your mind. What would you like to work through?",
      "Every relationship has challenges. I'm here to help you navigate yours."
    ],
    /family|mom|dad|parent|sister|brother/i => [
      "Family dynamics can be complicated. What's going on with your family?",
      "Our families shape us in so many ways. Tell me about what's happening.",
      "Family relationships are unique. I'm listening to understand your experience."
    ],
    /work|job|boss|career/i => [
      "Work stress is very real. What's been challenging at your job?",
      "Your career is important, but so is your wellbeing. What's going on at work?",
      "Let's talk about what's happening with your job. You deserve support."
    ],
    /thank|thanks|appreciate/i => [
      "You're very welcome. I'm glad I could help. How are you feeling now?",
      "It's my pleasure. Remember, you're doing important work by being here.",
      "Thank you for trusting me with your feelings. That takes strength."
    ],
    /better|improved|progress/i => [
      "I'm so proud of your progress! Growth isn't always linear, but you're moving forward.",
      "That's wonderful to hear! What do you think has helped you feel better?",
      "Your improvement is a testament to your resilience. Keep going!"
    ]
  }.freeze

  OPENING_LINES = [
    "Hello, I'm so glad you're here. How are you feeling today?",
    "Welcome. This is a safe space for you. What's on your mind?",
    "Hi there. Thank you for coming to talk. What would you like to explore today?",
    "Hello. I'm here to listen and support you. How have you been?"
  ].freeze

  FALLBACK_RESPONSES = [
    "I hear you. Can you tell me more about that?",
    "That sounds important. Help me understand what you're experiencing.",
    "I'm listening. What else would you like to share?",
    "How does that make you feel?",
    "That must be difficult. Tell me more.",
    "I want to understand. Can you expand on that?",
    "Your feelings matter. What else is going on?",
    "I'm here with you. Keep talking, I'm listening.",
    "That's a lot to process. How are you handling it?",
    "Thank you for sharing that with me. What are you thinking now?"
  ].freeze

  def initialize
    puts "🛋️ Therapist Mode Activated"
    puts "   Calm, supportive, professional"
    puts "   Say 'goodbye' or 'end session' to finish\n\n"
    check_mic
    ComfyTTS.setup
    @conversation_count = 0
  end

  def check_mic
    unless system('which termux-speech-to-text > /dev/null 2>&1')
      puts "❌ Error: termux-api required for voice input"
      puts "   Install: pkg install termux-api"
      exit 1
    end
  end

  def listen
    puts "\n🎤 Listening... (I'm here for you)"
    result = `termux-speech-to-text 2>/dev/null`.strip

    return nil if result.empty?

    @conversation_count += 1
    puts "   [#{@conversation_count}] You: #{result}"
    result
  end

  def speak(text)
    puts "   🛋️ Therapist: #{text}\n"
    ComfyTTS.speak(text)
    sleep(0.5)
  end

  def get_response(input)
    return nil if input =~ /goodbye|end session|done|finish/i

    RESPONSES.each do |pattern, responses|
      return responses.sample if input =~ pattern
    end

    FALLBACK_RESPONSES.sample
  end

  def start
    speak(OPENING_LINES.sample)

    loop do
      user_input = listen

      unless user_input
        speak("I didn't catch that. It's okay, take your time.")
        next
      end

      response = get_response(user_input)

      unless response
        speak("Thank you for sharing today. You did great work. Take care of yourself, and I'm here whenever you need to talk.")
        break
      end

      speak(response)
    end
  end
end

trap("INT") do
  puts "\n\n🛋️ Session ended. Remember, you're doing better than you think."
  exit
end

TherapistVoice.new.start
