#!/usr/bin/env ruby

# Replicate AI Voice - High Quality TTS using Replicate API
# Uses XTTS-V2 or other premium models for superior voice quality

require 'net/http'
require 'json'
require 'fileutils'
require 'uri'

class ReplicateVoice
  def initialize
    @api_token = ENV['REPLICATE_API_TOKEN']
    @cache_dir = File.expand_path("~/.tts_cache_replicate")
    FileUtils.mkdir_p(@cache_dir)

    @topics = [
      "Welcome to high-quality AI voice synthesis powered by Replicate!",
      "This voice is generated using state-of-the-art neural TTS models.",
      "The difference in quality should be immediately noticeable.",
      "Advanced AI models like XTTS can clone voices and speak multiple languages.",
      "This is the future of text-to-speech technology.",
      "Premium voice synthesis creates incredibly natural and expressive speech.",
      "Listen to the clarity, emotion, and human-like qualities in this voice.",
      "AI voice technology has advanced tremendously in recent years.",
      "We're using Replicate's API to access the best TTS models available.",
      "This beats basic TTS engines by a significant margin in quality."
    ]

    puts "🎙️ Initializing Replicate AI Voice..."
    check_setup
  end

  def check_setup
    if @api_token.nil? || @api_token.empty?
      puts "\n⚠️  No REPLICATE_API_TOKEN found!"
      puts "   To use Replicate API:"
      puts "   1. Sign up at https://replicate.com"
      puts "   2. Get your API token from account settings"
      puts "   3. Export it: export REPLICATE_API_TOKEN='your-token-here'"
      puts "   4. Add to ~/.bashrc for persistence\n"
      puts "   Falling back to local gTTS for now...\n"
      @use_fallback = true
    else
      puts "✅ Replicate API token found!"
      @use_fallback = false
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end
  end

  def generate_with_replicate(text)
    # Use XTTS-V2 model on Replicate
    uri = URI('https://api.replicate.com/v1/predictions')

    request = Net::HTTP::Post.new(uri)
    request['Authorization'] = "Token #{@api_token}"
    request['Content-Type'] = 'application/json'

    request.body = {
      version: "coqui/xtts-v2",
      input: {
        text: text,
        speaker: "https://replicate.delivery/pbxt/Jt79w0xsT64R1JsiJ0LQRL8UcWspg5Q4RQwK0mNPm4TQ6RP/female.wav",
        language: "en"
      }
    }.to_json

    response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
      http.request(request)
    end

    result = JSON.parse(response.body)

    # Poll for completion
    if result['urls'] && result['urls']['get']
      prediction_url = result['urls']['get']
      audio_url = poll_prediction(prediction_url)
      return audio_url
    end

    nil
  rescue => e
    puts "   [API Error: #{e.message}]"
    nil
  end

  def poll_prediction(url)
    max_attempts = 30
    attempts = 0

    while attempts < max_attempts
      uri = URI(url)
      request = Net::HTTP::Get.new(uri)
      request['Authorization'] = "Token #{@api_token}"

      response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
        http.request(request)
      end

      result = JSON.parse(response.body)

      if result['status'] == 'succeeded'
        return result['output']
      elsif result['status'] == 'failed'
        return nil
      end

      sleep 1
      attempts += 1
    end

    nil
  end

  def speak_with_fallback(text)
    # Use gTTS as fallback
    text_hash = text.hash.abs.to_s
    audio_file = "#{@cache_dir}/gtts_#{text_hash}.mp3"

    unless File.exist?(audio_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com'); tts.save('#{audio_file}')\" 2>/dev/null")
    end

    if File.exist?(audio_file) && File.size(audio_file) > 0
      system("play-audio #{audio_file} 2>/dev/null")
    else
      system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end
  end

  def speak(text)
    puts "\n🎙️ #{text}"

    if @use_fallback
      speak_with_fallback(text)
    else
      puts "   [Generating with Replicate AI...]"
      audio_url = generate_with_replicate(text)

      if audio_url
        # Download and play
        audio_file = "#{@cache_dir}/replicate_#{text.hash.abs}.wav"
        system("wget -q -O #{audio_file} '#{audio_url}' && play-audio #{audio_file}")
      else
        puts "   [Falling back to gTTS...]"
        speak_with_fallback(text)
      end
    end

    sleep(0.7)
  end

  def start
    puts "\n🎙️ Starting Replicate AI Voice!"
    puts "    Quality: Premium Neural TTS\n\n"

    speak("Initializing premium AI voice synthesis.")

    loop do
      @topics.each do |topic|
        speak(topic)
      end

      speak("Continuing with high-quality voice generation.")
    end
  end
end

trap("INT") do
  puts "\n\n🎙️ AI Voice session ended. Goodbye!"
  exit
end

bot = ReplicateVoice.new
bot.start
