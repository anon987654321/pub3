#!/usr/bin/env ruby

# Awkward Therapist - Uncomfortable discussing intimacy/relationships
# Socially awkward but trying their best

require_relative 'comfy_tts'

class AwkwardTherapist
  TOPICS = [
    "So... um... let's talk about... *clears throat* ...intimacy. This is perfectly normal to discuss. I do this all the time. Totally comfortable.",
    "Right, so... physical relationships. Yes. That's... that's a thing people have. Moving on to... wait, we should probably address this properly.",
    "Okay, deep breath. Sex. There, I said it. It's just three letters. S-E-X. Why is my voice cracking?",
    "Your relationship with... *nervous laugh* ...pleasure. Self-pleasure. Oh god, I shouldn't have said it twice. Let's just... continue.",
    "Studies show that... um... regular intimacy improves... you know... stuff. Health stuff. I'm a professional, I swear.",
    "Let's discuss boundaries in... in the bedroom. Did it get hot in here or is it just me? It's probably just me.",
    "Communication during... during... you know. THE ACT. There, we're adults. We can say THE ACT without giggling. Dammit, I giggled.",
    "Your sexual history is important for... for therapy reasons. Not that I'm curious! Purely clinical! That sounded worse.",
    "Fantasies are completely normal. Everyone has them. Even me. ESPECIALLY NOT ME. I mean... this is going poorly.",
    "Performance anxiety affects many people. Not me though. I mean, not that... I'm not talking about my performance. YOUR performance. Wait.",
    "Let's explore what brings you satisfaction in... in intimate moments. I'm reading this from a textbook in my head. It's fine.",
    "Open relationships, polyamory, kinks... all valid! I'm very sex-positive! Extremely progressive! Is my face red?",
    "The frequency of... of relations... in your partnership is... statistically... I forgot what I was saying. Your turn to talk.",
    "Erectile dysfunction and vaginal dryness are common issues we can... oh no, I said both at once. Medical terms are supposed to make this easier!",
    "Your first time is often... awkward. Like this conversation! Ha! Self-awareness doesn't make it less awkward though.",
    "Consent is crucial. Yes! Safe topic! Everyone agrees consent is good! Why am I shouting?",
    "Birth control, STI prevention... these are important! See, I can do sex ed! I'm totally mature about this!",
    "The emotional component of physical intimacy often... intertwines with... look, I'm trying really hard here.",
    "Your attraction patterns and preferences reveal... psychological... things. That was vague. I'll work on that.",
    "We should wrap up. I mean, conclude the session! Not 'wrap up' as in... protection. Although that's important too! See you next week!"
  ]

  NERVOUS_FILLER = [
    "*adjusts glasses nervously*",
    "*fidgets with pen*",
    "*clears throat multiple times*",
    "*checks notes intensely*",
    "*looks anywhere but at you*",
    "*takes long sip of water*",
    "*straightens papers unnecessarily*"
  ]

  def initialize
    puts "😰🛋️  AWKWARD THERAPIST MODE"
    puts "   Trying his best, really uncomfortable\n\n"
    ComfyTTS.setup
    @session_count = 0
  end

  def speak(text)
    # Add nervous filler occasionally
    if rand < 0.3
      text = "#{NERVOUS_FILLER.sample} #{text}"
    end

    puts "   💬 #{text}\n"
    ComfyTTS.speak(text, speed: 0.95, pitch_adjust: 20)
    sleep(rand(1..2))
  end

  def start
    speak("Hello! Welcome to... *nervous laugh* ...therapy. I'm very qualified. Let's discuss... things. Uncomfortable things. Because I'm a professional.")

    loop do
      @session_count += 1

      if @session_count == 1
        speak("So! Let's start with something easy. How's your... your love life? Oh god, that's not easy. Pretend I led into that better.")
      end

      speak(TOPICS[@session_count % TOPICS.length])

      if @session_count % 5 == 0
        speak("*takes off glasses and rubs eyes* I've been doing this for years. It gets easier. That's what I tell myself anyway.")
      end

      if @session_count % 10 == 0
        speak("You know what? You're handling this better than I am. That's... that's actually pretty common. Moving forward!")
      end

      sleep(3)
    end
  end
end

trap("INT") do
  puts "\n\n😰 Session ended! Same time next week? Please say yes, I need the practice."
  exit
end

AwkwardTherapist.new.start
