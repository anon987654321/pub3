#!/usr/bin/env ruby

# Natural Voice Continuous Dialogue using gTTS
# Much better quality than espeak, uses Google's TTS

require 'fileutils'

class NaturalTalkBot
  def initialize(custom_text = nil)
    @custom_text = custom_text
    @cache_dir = File.expand_path("~/.tts_cache")
    FileUtils.mkdir_p(@cache_dir)
    check_dependencies if @custom_text.nil?
  end

  def check_dependencies
    # Check for Python and gTTS
    unless system('which python3 > /dev/null 2>&1')
      puts "Installing Python..."
      system('pkg install -y python')
    end

    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    # Check for audio player
    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end
  end

  def speak(text)
    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"

      unless File.exist?(audio_file)
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.uk', slow=True); tts.save('#{audio_file}')\" 2>/dev/null")
      end

      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("play-audio #{audio_file} 2>/dev/null")
      else
        raise "Failed to generate audio"
      end

    rescue => e
      system("espeak -s 140 -a 80 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end
  end

  def start
    if @custom_text
      speak(@custom_text)
    end
  end
end

# Handle command line argument or default behavior
if ARGV.length > 0
  bot = NaturalTalkBot.new(ARGV.join(" "))
  bot.start
else
  puts "Usage: #{$0} 'text to speak'"
  exit 1
end
