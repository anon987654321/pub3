#!/usr/bin/env ruby

# Comfy Voice - Relaxing, Soothing TTS with Comfortable SoX Effects
# Warm, gentle, easy-listening voice for extended comfort

require 'fileutils'

class ComfyVoice
  def initialize
    @topics = [
      "Welcome to comfy voice mode. Just relax and listen.",
      "This voice is designed to be gentle and easy on the ears.",
      "Soft, warm tones create a comfortable listening experience.",
      "Let the soothing sounds help you relax and unwind.",
      "Comfortable audio makes extended listening much more pleasant.",
      "These gentle effects are carefully tuned for maximum comfort.",
      "Just sit back, relax, and enjoy the calm voice.",
      "Warm bass and soft treble create a cozy audio environment.",
      "This is like having a friend speaking softly beside you.",
      "Comfy voice - designed for your listening pleasure.",
      "The gentle rhythm and tone help create a peaceful atmosphere.",
      "Let these soothing sounds accompany your day.",
      "Comfortable audio is perfect for background listening.",
      "Warm, inviting tones make this voice easy to listen to for hours.",
      "Just breathe and enjoy the comfortable soundscape.",
      "This voice is your companion for relaxation and comfort.",
      "Gentle effects create a non-fatiguing listening experience.",
      "Comfort and clarity combined in perfect harmony.",
      "Let the warm tones ease your mind and relax your senses.",
      "This is comfy voice - your audio comfort zone."
    ]

    puts "🛋️ Initializing comfy voice mode..."
    check_dependencies
    @cache_dir = File.expand_path("~/.tts_cache_comfy")
    FileUtils.mkdir_p(@cache_dir)
  end

  def check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end

    unless system('which sox > /dev/null 2>&1')
      puts "Installing sox for comfy effects..."
      system('pkg install -y sox')
    end
  end

  def speak(text)
    puts "\n🛋️ #{text}"

    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"
      comfy_file = "#{@cache_dir}/comfy_#{text_hash}.wav"

      unless File.exist?(comfy_file)
        # Generate with slower, calmer pace
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.uk', slow=False); tts.save('#{audio_file}')\" 2>/dev/null")

        if File.exist?(audio_file) && File.size(audio_file) > 0
          # Comfy effects: slight pitch down, warm bass, reduced treble, gentle compression, soft chorus
          system("sox #{audio_file} #{comfy_file} pitch -80 bass +3 treble -3 compand 0.3,1 6:-70,-60,-20 -5 -90 0.2 chorus 0.5 0.9 50 0.4 0.25 2 -s norm -3 2>/dev/null")
        end
      end

      if File.exist?(comfy_file) && File.size(comfy_file) > 0
        system("play-audio #{comfy_file} 2>/dev/null")
      else
        raise "Failed to generate comfy voice"
      end

    rescue => e
      puts "   [Error: #{e.message}]"
      system("espeak -s 140 -p 40 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.9)  # Longer pause for relaxed pacing
  end

  def start
    puts "\n🛋️ Starting Comfy Voice Mode!"
    puts "    Effects: Warm Bass + Soft Treble + Gentle Chorus + Compression\n"
    puts "    Perfect for extended, relaxed listening\n\n"

    speak("Comfy voice mode activated. Just relax and enjoy.")

    loop do
      @topics.each do |topic|
        speak(topic)
      end

      speak("Continuing with gentle, comfortable conversation.")
    end
  end
end

trap("INT") do
  puts "\n\n🛋️ Comfy voice ending. Rest well!"
  system("python3 -c \"from gtts import gTTS; tts = gTTS('Take care. Rest well.', lang='en', tld='co.uk'); tts.save('/tmp/bye_comfy.mp3')\" 2>/dev/null")
  system("sox /tmp/bye_comfy.mp3 /tmp/bye_comfy.wav pitch -80 bass +3 treble -3 compand 0.3,1 6:-70,-60,-20 -5 -90 0.2 norm -3 2>/dev/null")
  system("play-audio /tmp/bye_comfy.wav 2>/dev/null")
  File.delete("/tmp/bye_comfy.mp3") if File.exist?("/tmp/bye_comfy.mp3")
  File.delete("/tmp/bye_comfy.wav") if File.exist?("/tmp/bye_comfy.wav")
  exit
end

bot = ComfyVoice.new
bot.start
