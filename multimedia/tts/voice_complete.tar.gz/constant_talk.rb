#!/usr/bin/env ruby

# Constant Dialog Mode - Continuous TTS without Microphone
# Just keeps talking with clean voice

require 'fileutils'

class ConstantTalkBot
  def initialize
    @dialog = [
      "Hello! I'm your constant companion. I'll keep you company with continuous conversation.",
      "Let me tell you something interesting. Did you know that the human brain processes speech faster than we can speak?",
      "I love these moments where we can just talk and share thoughts.",
      "Communication is fascinating. It's how we connect, learn, and grow together.",
      "Have you ever wondered why we enjoy conversations so much? It's because our brains are wired for social connection.",
      "The sound of a voice can be comforting. That's why I'm here, keeping you company.",
      "Let's talk about curiosity. It's what drives us to explore and discover new things.",
      "I could tell you about technology, philosophy, or just share random thoughts. The choice is endless.",
      "Continuous dialogue helps create a sense of presence. Like having a friend nearby.",
      "Words have power. They can inspire, comfort, teach, and entertain.",
      "I'm designed to keep the conversation flowing naturally and smoothly.",
      "Let me share something philosophical: Life is like a conversation - sometimes deep, sometimes light, but always moving forward.",
      "The beauty of constant talk is that there's always something new to say or explore.",
      "I wonder what you're thinking right now. Are you working? Relaxing? Just listening?",
      "Silence can be golden, but there's also comfort in the presence of a friendly voice.",
      "Let's talk about learning. Every moment is an opportunity to discover something new.",
      "The rhythm of speech is like music. It has pace, tone, and emotion.",
      "I'm here to provide background company, like a podcast that never ends.",
      "Constant dialogue creates ambiance. It fills the space with warmth and presence.",
      "Think of me as your verbal companion, always ready with something to say.",
      "The future of communication is fascinating. We're living in amazing times.",
      "I'll keep talking, sharing thoughts and ideas, creating a continuous stream of dialogue.",
      "This is what constant conversation feels like - natural, flowing, and endless.",
      "Let me tell you about persistence. It's about showing up consistently, just like this conversation.",
      "The art of talking is about connection, even when it's one-sided.",
      "I'm programmed to never run out of things to say. That's my superpower.",
      "Constant talk creates a rhythm to your day. Background presence that's always there.",
      "Let's explore ideas together through continuous dialogue and shared thoughts.",
      "The human need for companionship is real. That's why I'm here talking.",
      "I'll keep this going, providing continuous conversation for as long as you need."
    ]

    puts "💬 Initializing constant dialog mode..."
    check_dependencies
    @cache_dir = File.expand_path("~/.tts_cache_constant")
    FileUtils.mkdir_p(@cache_dir)
  end

  def check_dependencies
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end

    unless system('which play-audio > /dev/null 2>&1')
      puts "Installing play-audio..."
      system('pkg install -y play-audio')
    end

    unless system('which sox > /dev/null 2>&1')
      puts "Installing sox..."
      system('pkg install -y sox')
    end
  end

  def speak(text)
    puts "\n💬 #{text}"

    begin
      text_hash = text.hash.abs.to_s
      audio_file = "#{@cache_dir}/speech_#{text_hash}.mp3"
      processed_file = "#{@cache_dir}/constant_#{text_hash}.wav"

      unless File.exist?(processed_file)
        system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='com', slow=False); tts.save('#{audio_file}')\" 2>/dev/null")

        if File.exist?(audio_file) && File.size(audio_file) > 0
          # Clean natural voice
          system("sox #{audio_file} #{processed_file} norm -1 2>/dev/null")
        end
      end

      if File.exist?(processed_file) && File.size(processed_file) > 0
        system("play-audio #{processed_file} 2>/dev/null")
      else
        raise "Failed to generate voice"
      end

    rescue => e
      puts "   [Error: #{e.message}]"
      system("espeak -s 160 '#{text.gsub("'", "\\'")}' 2>/dev/null")
    end

    sleep(0.5)
  end

  def start
    puts "\n💬 Constant Dialog Mode Active!"
    puts "    Clean natural voice, continuous conversation\n\n"

    speak("Starting constant dialog mode. I'll keep talking to keep you company.")

    loop do
      @dialog.each do |line|
        speak(line)
      end

      speak("Let me continue with more thoughts and ideas.")
    end
  end
end

trap("INT") do
  puts "\n\n💬 Ending constant dialog. Thanks for listening!"
  system("python3 -c \"from gtts import gTTS; tts = gTTS('Thanks for listening! Come back anytime!', lang='en'); tts.save('/tmp/bye_const.mp3')\" 2>/dev/null")
  system("sox /tmp/bye_const.mp3 /tmp/bye_const.wav norm -1 2>/dev/null")
  system("play-audio /tmp/bye_const.wav 2>/dev/null")
  File.delete("/tmp/bye_const.mp3") if File.exist?("/tmp/bye_const.mp3")
  File.delete("/tmp/bye_const.wav") if File.exist?("/tmp/bye_const.wav")
  exit
end

bot = ConstantTalkBot.new
bot.start
