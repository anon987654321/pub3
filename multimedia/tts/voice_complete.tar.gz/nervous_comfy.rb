#!/usr/bin/env ruby

# Nervous Comfy Voice - Insecure + Comfy effects combined
# The funniest anxious voice with prosody variations

require 'fileutils'

class NervousComfy
  CACHE_DIR = File.expand_path("~/.tts_cache_nervouscomfy")
  # Combo: nervous tremolo + comfy pitch + bass + chorus for unique sound
  SOX_EFFECTS = "pitch 100 tremolo 7 50 bass +3 treble -2 chorus 0.5 0.9 50 0.4 0.25 2 -s tempo 0.92 norm -5"

  def self.setup
    FileUtils.mkdir_p(CACHE_DIR)
    unless system('python3 -c "import gtts" 2>/dev/null')
      puts "Installing gTTS..."
      system('pip install gTTS')
    end
  end

  def self.speak(text)
    setup
    text_hash = text.hash.abs.to_s
    audio_file = "#{CACHE_DIR}/speech_#{text_hash}.mp3"
    nervous_file = "#{CACHE_DIR}/nervous_#{text_hash}.wav"

    unless File.exist?(nervous_file)
      system("python3 -c \"from gtts import gTTS; tts = gTTS('#{text.gsub("'", "\\\\'")}', lang='en', tld='co.uk'); tts.save('#{audio_file}')\" 2>/dev/null")
      if File.exist?(audio_file) && File.size(audio_file) > 0
        system("sox #{audio_file} #{nervous_file} #{SOX_EFFECTS} 2>/dev/null")
      end
    end

    system("play-audio #{nervous_file} 2>/dev/null") if File.exist?(nervous_file) && File.size(nervous_file) > 0
  end
end

# FUNNY INSECURE JOKES
JOKES = [
  "I wrote a joke but I'm not sure if it's funny... okay here goes... why did the programmer quit? Because he didn't get arrays... was that okay?",
  "Um, so there's this thing where, uh, programmers prefer dark mode because... well... light attracts bugs. Sorry if you've heard that one.",
  "I hope this doesn't offend anyone but... there are 10 types of people... binary joke... yeah...",
  "This might be stupid but... why do Java developers wear glasses? Because they can't C Sharp... I'll stop now.",
  "I'm sorry in advance for this one... what's a pirate's favorite language? Arrrrr... I know, I know, it's terrible.",
  "Please don't hate me but... why was the JavaScript developer sad? Because he didn't Node how to Express himself... okay I'm done.",
  "I rehearsed this and it's still bad... what do you call a programmer from Finland? Nerdic... that was awful, wasn't it?",
  "This joke bombed last time but... why did the database administrator leave his wife? She had one-to-many relationships... sorry.",
  "I'm really nervous about this one... how do you comfort JavaScript? You console it... please don't unsubscribe.",
  "Last one I promise... why do programmers always mix up Halloween and Christmas? Because Oct 31 equals Dec 25... I'll see myself out."
]

# AWKWARD OBSERVATIONS
OBSERVATIONS = [
  "Is anyone else sweating or is the server room just really hot right now?",
  "I think my code has more issues than I do. And that's saying something.",
  "Do you ever feel like your imposter syndrome has imposter syndrome?",
  "I debugged my code for 3 hours. The bug was a missing semicolon. I'm fine, everything's fine.",
  "My git commits are just increasingly desperate apologies at this point.",
  "I said I'd fix it in production. That was a mistake. Everything is a mistake.",
  "Stack Overflow is just my anxiety in website form. Did I do it right? Please validate me.",
  "I wrote clean code once. Then I had to add a feature.",
  "My error messages are more judgmental than my relatives at Thanksgiving.",
  "I'm not saying I'm bad at coding, but my rubber duck quit."
]

if ARGV.length > 0
  NervousComfy.speak(ARGV.join(" "))
else
  puts "😰🛋️  NERVOUS COMFY VOICE - Insecure Prosody Edition"
  puts "="*50

  puts "\n😅 ANXIOUS PROGRAMMER JOKES:"
  JOKES.sample(5).each_with_index do |joke, i|
    puts "\n[#{i+1}] #{joke}"
    NervousComfy.speak(joke)
    sleep(2.5)
  end

  puts "\n\n🤦 AWKWARD OBSERVATIONS:"
  OBSERVATIONS.sample(5).each do |obs|
    puts "\n   #{obs}"
    NervousComfy.speak(obs)
    sleep(2)
  end

  puts "\n\n😰 Thanks for tolerating this awkward comedy show..."
end
